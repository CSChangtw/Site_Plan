---
name: plan-tw-site-facility-layout
description: 依台灣公共工程法規規劃與審查土建工地施工總平面（圍籬、大門、洗車台、告示牌、場內道路、工務所、男女廁所浴室、材料堆置場、加工場、起重機、施工構台、出土坡道、施工架、臨時用電、截水沉砂），以程式自動繪製依比例之整體配置圖與 15 張構造詳圖（PNG/SVG/PDF/DXF），並自動以 Canvas 互動圖（單檔 HTML）呈現，另以程式繪製可旋轉之 3D 鳥瞰圖並產生 AI 鳥瞰示意圖提示詞。使用時機：編製施工計畫之工地配置圖、審查總平面佈置方案找衝突缺項、查詢營造安全衛生設施標準或營建工程空氣污染防制設施管理辦法之設施控制值、繪製圍籬、洗車台、施工架、護欄、構台等構造詳圖、分階段總平圖核對漏項時。
---

# plan-tw-site-facility-layout（土建工地設施配置圖）

## Summary

把使用者提供的工地條件轉成 site.json，先檢查缺漏，資料齊全後執行 scripts/sitelayout.py，產生依比例之施工總平面配置圖、佈置審查意見、構造詳圖、Canvas 互動圖與 AI 示意圖提示詞。法規數值只來自 scripts/rules.json（每項附依據、條號與核對狀態）；項目、尺寸、數量一律由使用者提供，不以預設值代替。

## When to Use

- 「幫我畫工地配置圖／總平面佈置圖」「這個佈置有沒有問題」「主體階段總平圖漏了什麼」
- 「圍籬要多高」「洗車台怎麼做」「施工架繫牆間距」「構台覆工板間隙」等控制值查詢
- 「畫圍籬／大門／洗車台／告示牌／構台／坡道／開挖護欄／施工架／護欄／護蓋／臨電／截水溝／工務所／廁所浴室／堆置場詳圖」
- 「做一張工地 3D 鳥瞰圖」（程式 3D 鳥瞰圖；另可產生 AI 示意圖提示詞）

## Steps

1. 判斷需求：查控制值（regulations.md、elements.md）／出清單（stages_review.md）／審方案／出圖。純查詢直接回答，不跑程式。
2. **先詢問，不推估**。出圖或審查前，凡使用者提示語未明確提供之項目、尺寸、數量（工程類別、面積、工期、階段、防制區、縣市、臨路、圍籬高度、大門位置寬度、各設施位置尺寸、便器數、開挖深度、起重機半徑、架空電線、車寬、詳圖尺寸等），一律先問；不得自行配置、不得套預設值或示意值。
   - 把已知資料寫成 site.json（格式見 drafting_details.md 第二節），執行 `python3 scripts/sitelayout.py check --site site.json [--detail D03 D08] [--param k=v ...]`。
   - 結束碼 3 表示缺漏：依 questions.md 列出之問題，以 AskUserQuestion（可用時）或條列方式一次問完，同一主題合併成一題；取得答覆後補入 site.json 再檢查，直到「資料齊全」。
   - 使用者說「塔吊放哪合適」這類一句話問題，先問結構形式、基坑、周邊建物，再依 elements.md 給原則。
   - 使用者明確表示「先用示意值畫」時才加 `--allow-demo`，圖面與回覆都標「示意」。
3. 執行：
   ```
   python3 scripts/sitelayout.py layout site.json -o out
   python3 scripts/sitelayout.py detail D03 --param l=8 w=3.5 --site site.json -o out
   python3 scripts/sitelayout.py details --ids D01 D08 --param D01.post=2.4 D08.h=45 D08.l=30 D08.lift=1.7 D08.bay=1.829 --site site.json -o out
   ```
   產出：site_layout.png/.svg/.pdf/.dxf、review.md/json、site_canvas.html、prompt_layout.txt、rules_all.csv、verify_list.csv；詳圖 Dxx.*、Dxx_canvas.html 或 details_canvas.html、details_all.pdf。
4. **自動以 Canvas 呈現**（不必等使用者要求）：每次出圖後，把 site_canvas.html（詳圖為 details_canvas.html 或 Dxx_canvas.html）以 HTML artifact 呈現在 claude.ai 的 Canvas 面板（有 Artifact 發布工具時發布該檔；沒有時以檔案預覽呈現）。圖面可縮放、平移、切換圖層、切換圖紙、匯出 PNG，側欄附附註與審查結果。PNG、PDF、DXF 另以檔案交付。
5. 目視檢查 site_layout.png 與詳圖（標籤重疊、設施越界）；有問題向使用者確認位置後修改 site.json 重跑，不自行搬動設施。
6. 3D 鳥瞰圖：`python3 scripts/sitelayout.py birdview site.json -o out`，產出 birdview_3d.html（可旋轉、縮放、切換視角、匯出 PNG）與 birdview_3d.png；HTML 同樣以 artifact 自動呈現。位置與尺寸取自 site.json，設施高度除構造物、圍籬、施工架外為顯示用示意值（可以 facilities[].height_m 指定），回覆中須說明。
7. AI 示意圖（選用）：有 GEMINI_API_KEY 或 OPENAI_API_KEY 時執行 `python3 scripts/gen_ai_image.py out/prompt_layout.txt -o out/ai_birdview.png`；沒有金鑰就交付提示詞檔，並說明可貼到 Gemini 或 ChatGPT 生圖。顯示所用提示詞全文。
8. 回覆：先給審查結論（不符、缺項數與最重要 3 項），再交付檔案；【待核】項目提醒使用者以 verify_list.csv 核對。審查意見格式依 templates_glossary.md 模板 1。

## 參考檔（需要時才讀）

| 檔案 | 內容 | 何時讀 |
|---|---|---|
| references/regulations.md | 70 項規則值、依據、狀態（與 rules.json 同步） | 引用任何數值前 |
| references/elements.md | 34 類設施要素佈置原則與控制值 | 回答要素查詢、提出佈置原則供使用者決定 |
| references/stages_review.md | 9 階段圖面清單、R00～R19 審查規則、5 類風險 | 核對漏項、解釋審查結果 |
| references/drafting_details.md | 圖層線型、site.json 格式、15 張詳圖必要參數 | 建 site.json、詢問詳圖尺寸、出圖 |
| references/image_prompts.md | 五段式生圖提示詞、平台呼叫規則 | 產生或微調 AI 示意圖 |
| references/templates_glossary.md | 三套輸出模板、詢問順序、術語 | 撰寫審查意見、組織詢問 |

## Gotchas

- 未提供即詢問：設施位置、尺寸、數量都屬使用者決定事項，elements.md 的原則只能當建議供使用者選擇，不能直接寫入 site.json。
- 數值只引用 rules.json／regulations.md，並寫出「法規＋條號＋狀態」。【待核】值照列，不改寫為確定語氣；【地方】值（臺北市、新北市、桃園市）只用於該縣市。
- 不同工程類別（建築、道路、管線、橋梁）之分級門檻不得互套；不得引用中國大陸、美國 OSHA 等規範數值代替台灣規定。
- 程式圖與 Canvas 圖為正式圖；AI 示意圖無比例且中文易錯字，只能用於簡報，回覆中須註明。
- details_standard.pdf 為參考用標準詳圖（以示意尺寸繪製），不得當成本案詳圖交付。
- 基坑周邊堆載、構台、7 m 以上施工架、塔吊基礎附牆、臨電負載須由專任工程人員、技師或合格電機人員設計簽章，本 skill 不取代。
- 範例與輸出不放真實單位、人名與電話，以「○○」代替。拒絕規避檢查或與現場不符之圖說請求。
- DXF 為 R12、Big5，中文字型 chineset.shx；中文字型由程式自動偵測，找不到時安裝 Noto Sans CJK TC 後重跑，不得改用英文標籤。

## 範圍與限制

本 skill 依台灣現行法規（110～113 年版次核對）整理；實際施工以契約圖說、核定之施工計畫及主管機關最新規定為準，並由專業工程師判斷。
