# 出圖規範、輸入格式與構造詳圖規格

## 一、出圖規範

### 1. 底圖處理（套用 CAD 或地籍底圖時）
1. 以地籍圖或測量成果確定基地界線，座標統一為公尺、x 向東、y 向北。
2. 刪除與施工配置無關之圖層（家具、填充、標註），保留建築外框、柱位、開挖範圍、臨接道路、既有管線與架空電線。
3. 底圖鎖定於「20-構造物」圖層、灰色；施工配置畫於本表其他圖層，避免改到設計圖。
4. 分階段套圖：同一底圖、不同階段各存一檔（L-01 S1、L-02 S3…），圖號與階段名稱寫入圖框。

### 2. 圖層、顏色、線型（程式 DXF 輸出採相同設定，ACI 顏色號）

| 圖層 | 內容 | 顏色 | 線型 |
|---|---|---|---|
| 00-基地界線 | 地界線 | 紅 1 | 一點鏈線 |
| 01-圍籬 | 圍籬、警示燈 | 綠 3 | 實線 |
| 02-出入口 | 大門、出入方向 | 橙 30 | 實線粗 |
| 03-道路鋪面 | 場內道路、鋪面、停放 | 灰 8 | 實線，中心虛線 |
| 04-臨時建物 | 工務所、廁所、浴室、休息、警衛 | 藍 5 | 實線 |
| 05-堆置加工 | 堆置場、加工場、土方暫置 | 褐 34 | 實線 |
| 06-機械起重 | 起重機、作業半徑、提升機 | 紫 6 | 虛線 |
| 07-開挖擋土 | 開挖範圍、擋土、構台、坡道 | 粉紅 200 | 虛線／實線 |
| 08-臨時用電 | 配電盤、分電箱、電纜路徑、架空電線 | 黃 2 | 虛線（電線一點鏈線紅） |
| 09-給排水 | 截水溝、給水 | 青 4 | 實線 |
| 10-安全設施 | 護欄、告示、滅火器、急救 | 紅 1 | 實線 |
| 11-環保設施 | 洗車台、沉砂池、廢棄物、監視器 | 深綠 94 | 實線 |
| 20-構造物 | 新建／既有構造物、底圖 | 白／黑 7 | 實線 |
| 90-標註、91-尺寸 | 文字、尺寸 | 7、8 | 實線 |

DXF 為 R12、文字 cp950（Big5），字型 txt.shx＋chineset.shx；AutoCAD 開啟若中文缺字，改用 chineset.shx 或 Big5 大字體。

### 3. 比例與圖框
- 總平面：A3 依基地大小自動選 1:100～1:1000；詳圖 1:10～1:250；單線圖不依比例（NTS）。
- 圖框右側標題欄：工程名稱、圖名、圖號、比例、日期、附註（每條附依據與狀態）、設計／繪圖／校核／審查簽認欄。
- 指北針、比例尺、圖例為總平面必備。
- 狀態標記：【已核】【待核】【地方】【示意】；示意值旁加「（示意）」。

## 二、site.json 輸入格式（座標公尺）

```json
{
  "project": {"name": "", "stage": "S5 地上結構", "type": "building|road|pipe|bridge", "city": "",
              "area_m2": 0, "duration_months": 0, "air_zone": 1, "engineering_level": null,
              "public_work": true, "above_audit_amount": true,
              "workers": {"male": 0, "female": 0}, "paved_ratio": 0.9, "export_soil_m3": 0, "eia": false},
  "site": {"boundary": [[x,y],...], "north_deg": 0, "roads": [{"name": "", "width": 12, "line": [[x,y],[x,y]]}]},
  "fence": {"height_m": 2.4},
  "vehicle": {"max_width_m": 2.5},
  "building": {"footprint": [[x,y],...], "label": "", "height_m": 0},
  "excavation": {"polygon": [[x,y],...], "depth_m": 0, "shoring": ""},
  "scaffold": {"height_m": 0, "facade_area_m2": 0},
  "gates": [{"id": "G1", "at": [x,y], "width": 8, "dir": "S|N|E|W", "main": true, "haul": true}],
  "haul_roads": [{"id": "R1", "line": [[x,y],...], "width": 6.5, "one_way": false, "pavement": "混凝土"}],
  "cranes": [{"id": "TC1", "at": [x,y], "radius": 40, "label": ""}],
  "power_lines": [{"line": [[x,y],...], "voltage_kv": 11.4}],
  "drains": [{"line": [[x,y],...], "label": "截水溝"}],
  "power_routes": [[[x,y],[x,y]]],
  "facilities": [{"id": "F1", "type": "office", "label": "", "x": 0, "y": 0, "w": 0, "h": 0, "rot": 0}],
  "check": {"washer_gate_max_m": 30}
}
```

facilities.type：office 工務所、toilet 廁所（加 seats_m、urinals、seats_f）、shower 浴室、rest 休息室、guard 警衛室、lab 試驗室、store 材料堆置、rebar 鋼筋加工、formwork 模板、precast 預鑄、waste 廢棄物、soil 土方暫置、washer 洗車台、sedtank 沉砂池、panel 總配電盤、subpanel 分電箱、water 給水、sign 告示牌、fire 滅火器、firstaid 急救站、cctv 監視器、deck 構台、ramp 坡道、hoist 提升機、parking 機具停放、other 其他。x、y 為矩形左下角，rot 為逆時針角度。

缺資料時：執行前以 `check` 子指令檢查，缺漏項目寫入 questions.md 並停止（結束碼 3），須先詢問使用者；不得自行補值或自行配置。下列欄位為必要：project.name、stage、type、area_m2、duration_months、air_zone、city、public_work、above_audit_amount、workers.male／female、paved_ratio；site.boundary、site.roads；fence.height_m；vehicle.max_width_m；gates（位置、寬度、方向）；facilities（每項 x、y、w、h；廁所另需 seats_m、urinals、seats_f）；excavation、cranes、power_lines、haul_roads（無者填 null 或 []）；S5、S6 階段另需 scaffold。

## 三、構造詳圖 15 張（detail 子指令，--param 覆寫）

| 編號 | 圖名 | 法規控制值（自動帶入） | 必要參數（未提供須先詢問） |
|---|---|---|---|
| D01 | 施工圍籬 | 高度依分級、防溢座、面板厚、警示燈間距 | post（立柱間距）；h 或 site 之分級與防制區 |
| D02 | 施工大門 | 1.8 m 以下不透空【地方】 | w（門寬）、h |
| D03 | 洗車台及沉砂池 | 防溢座、收集坑、沉砂池；auto=1 時帶自動洗車規格 | l；w（或 auto=1＋truck_w） |
| D04 | 工程告示牌 | 應載明事項（空污、01581） | w、h、leg |
| D05 | 施工構台 | 覆工板間隙 ≤ 3 cm、護欄、設計簽章 | span、bays、h |
| D06 | 出土坡道 | 護欄、防翻落 | depth、slope_n、w |
| D07 | 開挖周邊護欄及擋土 | 擋土 1.5 m、護欄、堆積範圍＝H【待核】 | depth（或 site 之開挖深度） |
| D08 | 施工架及安全網 | 繫牆 5.5/7.5 m、工作臺 40 cm、間隙 20 cm、柱頂 1 m | h、l、lift、bay |
| D09 | 護欄標準 | 90／55／腳趾板／φ38／2.5 m／75 kgf | 無（l 為繪製段長，版面參數） |
| D10 | 開口護蓋 | 柵距 ≤ 3 cm、黃色警告 | a（開口邊長） |
| D11 | 臨時用電單線圖 | 30 mA 0.1 s、中感度條件、電焊機防電擊 | subpanels、loads（各分電箱供電對象） |
| D12 | 截水溝及沉砂池 | 逕流削減計畫、裸露地比例 | w、d |
| D13 | 工務所 | — | rooms（房間組成）、unit_w、unit_l |
| D14 | 男女廁所浴室 | 便器數依人數計算【待核】 | male、female（或 site 人數）、shower_m、shower_f |
| D15 | 材料堆置場 | 覆蓋、護欄前 2 m、開挖淨距、通道寬 | w、d、vehicle_w |

指令（參數齊全才會出圖；缺漏時輸出 questions.md 並停止）：
```
python3 scripts/sitelayout.py check --site site.json --detail D03 D08 --param l=8   # 只檢查缺漏
python3 scripts/sitelayout.py layout site.json -o out          # 總平面＋審查＋提示詞＋規則清單
python3 scripts/sitelayout.py detail D08 --param h=45 l=30 --site site.json -o out
python3 scripts/sitelayout.py details --ids D01 D08 --param D01.post=2.4 D08.h=45 --site site.json -o out
python3 scripts/sitelayout.py birdview site.json -o out          # 程式 3D 鳥瞰圖（HTML＋PNG）
python3 scripts/sitelayout.py prompt site.json -o out            # AI 鳥瞰圖提示詞
python3 scripts/sitelayout.py rules-list -o out                  # rules_all.csv、verify_list.csv
```
輸出：PNG（200 dpi）、SVG、PDF（字型內嵌）、DXF R12，及 Canvas 互動圖（site_canvas.html、Dxx_canvas.html、details_canvas.html；單檔 HTML，可縮放平移、切換圖層與圖紙、匯出 PNG）。

`--allow-demo`：僅於使用者明確同意以示意值繪製時使用，圖面附註標「示意」。
