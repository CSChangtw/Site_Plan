#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gen_ai_image.py - 以提示詞檔呼叫外部生圖 API 產生 AI 示意圖（選用）

用法：python3 gen_ai_image.py <prompt.txt> -o <out.png> [--provider gemini|openai] [--model 名稱]
金鑰：環境變數 GEMINI_API_KEY 或 OPENAI_API_KEY；皆無時結束並提示改貼至 Gemini／ChatGPT。
模型名稱會隨服務更新，預設值失效時以 --model 指定。只連線至所選服務之官方 API。
"""
import argparse, base64, json, os, sys, urllib.request


def gemini(prompt, model, key):
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
    body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseModalities": ["IMAGE", "TEXT"]}}
    req = urllib.request.Request(url, json.dumps(body).encode(), {"Content-Type": "application/json"})
    data = json.load(urllib.request.urlopen(req, timeout=180))
    for p in data["candidates"][0]["content"]["parts"]:
        if "inlineData" in p:
            return base64.b64decode(p["inlineData"]["data"])
    raise RuntimeError("回應未含影像：" + json.dumps(data)[:300])


def openai(prompt, model, key):
    req = urllib.request.Request("https://api.openai.com/v1/images/generations",
                                 json.dumps({"model": model, "prompt": prompt, "size": "1536x1024"}).encode(),
                                 {"Content-Type": "application/json", "Authorization": f"Bearer {key}"})
    data = json.load(urllib.request.urlopen(req, timeout=180))
    return base64.b64decode(data["data"][0]["b64_json"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prompt"); ap.add_argument("-o", "--out", default="ai_image.png")
    ap.add_argument("--provider", choices=["gemini", "openai"]); ap.add_argument("--model")
    a = ap.parse_args()
    prompt = open(a.prompt, encoding="utf-8").read()
    prov = a.provider or ("gemini" if os.getenv("GEMINI_API_KEY") else "openai" if os.getenv("OPENAI_API_KEY") else None)
    if not prov:
        print("未設定 GEMINI_API_KEY 或 OPENAI_API_KEY：請將提示詞檔內容貼至 Gemini 或 ChatGPT 生圖。", file=sys.stderr)
        sys.exit(2)
    try:
        if prov == "gemini":
            img = gemini(prompt, a.model or "gemini-2.5-flash-image", os.environ["GEMINI_API_KEY"])
        else:
            img = openai(prompt, a.model or "gpt-image-1", os.environ["OPENAI_API_KEY"])
    except Exception as e:
        print(f"生圖失敗（{prov}）：{e}\n請確認模型名稱與網路連線，或改貼提示詞至平台生圖。", file=sys.stderr)
        sys.exit(1)
    open(a.out, "wb").write(img)
    print(f"示意圖 → {a.out}（示意圖，尺寸與規定以程式圖為準）")


if __name__ == "__main__":
    main()
