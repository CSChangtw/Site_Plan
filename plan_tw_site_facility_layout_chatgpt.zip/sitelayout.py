#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""sitelayout.py - 土建工地設施配置圖：整體配置圖、構造詳圖、佈置審查、AI 生圖提示詞

子指令：
  layout   <site.json> -o <dir>      整體配置圖（PNG/SVG/PDF/DXF）＋審查意見（review.md/json）
  review   <site.json> -o <dir>      只做佈置審查
  detail   <D01..D15> -o <dir> [--param k=v ...] [--site site.json]   單張構造詳圖
  details  -o <dir> [--site site.json]   全部 15 張詳圖＋合併 PDF（details_all.pdf）
  birdview <site.json> -o <dir>      程式 3D 鳥瞰圖（birdview_3d.html 可旋轉＋birdview_3d.png）
  prompt   <site.json|Dxx> -o <dir>   產生 AI 生圖提示詞（五段式）
  check    --site site.json [--detail D03 ...] [--param k=v]  只檢查缺漏資料，列出須詢問事項
  rules-list -o <dir>                 匯出規則值與待核對清單（rules_all.csv、verify_list.csv）

缺漏資料：layout、detail、details 執行前自動檢查；有缺漏即輸出 questions.md 並以結束碼 3 停止，
不以預設值代替。僅在使用者明確同意以示意值繪製時加 --allow-demo（圖面標「示意」）。
每次繪圖同時輸出 *_canvas.html（單檔 Canvas 互動圖）。

數值規則全部來自 rules.json；本程式不另行補值。未由法規規定之尺寸以參數提供，
未提供者以「示意」標註於圖面。
"""
import argparse, csv, json, math, os, sys, datetime

HERE = os.path.dirname(os.path.abspath(__file__))
RULES = json.load(open(os.path.join(HERE, "rules.json"), encoding="utf-8"))["rules"]
VTAG = {"web": "已核", "false": "待核", "local": "地方", "design": "設計"}


def R(key):
    return RULES[key]["value"]


def cite(key):
    r = RULES[key]
    return f"{r['source']} {r['clause']}【{VTAG.get(r['verified'], r['verified'])}】"


# ───────────────────────── 繪圖核心（單位：公尺） ─────────────────────────
LAYERS = {
    "00-基地界線": ("#d62728", 1, "dashdot"),
    "01-圍籬": ("#2ca02c", 3, "solid"),
    "02-出入口": ("#ff7f0e", 30, "solid"),
    "03-道路鋪面": ("#7f7f7f", 8, "solid"),
    "04-臨時建物": ("#1f77b4", 5, "solid"),
    "05-堆置加工": ("#8c564b", 34, "solid"),
    "06-機械起重": ("#9467bd", 6, "dashed"),
    "07-開挖擋土": ("#e377c2", 200, "solid"),
    "08-臨時用電": ("#bcbd22", 2, "solid"),
    "09-給排水": ("#17becf", 4, "solid"),
    "10-安全設施": ("#d62728", 1, "solid"),
    "11-環保設施": ("#006400", 94, "solid"),
    "20-構造物": ("#000000", 7, "solid"),
    "90-標註": ("#000000", 7, "solid"),
    "91-尺寸": ("#555555", 8, "solid"),
}


class Canvas:
    def __init__(self):
        self.items = []

    def _add(self, **kw):
        self.items.append(kw)

    def line(self, pts, layer="20-構造物", lw=0.35, ls=None, color=None):
        self._add(k="line", pts=pts, layer=layer, lw=lw, ls=ls, color=color)

    def poly(self, pts, layer="20-構造物", lw=0.35, fill=None, alpha=1.0, hatch=None, ls=None, color=None):
        self._add(k="poly", pts=pts, layer=layer, lw=lw, fill=fill, alpha=alpha, hatch=hatch, ls=ls, color=color)

    def rect(self, x, y, w, h, **kw):
        self.poly([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], **kw)

    def circle(self, c, r, layer="20-構造物", lw=0.3, ls=None, fill=None, alpha=1.0, color=None):
        self._add(k="circle", c=c, r=r, layer=layer, lw=lw, ls=ls, fill=fill, alpha=alpha, color=color)

    def arc(self, c, r, a0, a1, layer="20-構造物", lw=0.3, ls=None):
        self._add(k="arc", c=c, r=r, a0=a0, a1=a1, layer=layer, lw=lw, ls=ls)

    def text(self, p, s, size=7, ha="center", va="center", rot=0, layer="90-標註", color="#000", bold=False):
        self._add(k="text", p=p, s=s, size=size, ha=ha, va=va, rot=rot, layer=layer, color=color, bold=bold)

    def dim(self, p1, p2, off, text=None, layer="91-尺寸", unit="cm", size=6.5):
        """平行尺寸：off 為法線方向偏移（公尺，正值向左側）。"""
        (x1, y1), (x2, y2) = p1, p2
        L = math.hypot(x2 - x1, y2 - y1)
        if L == 0:
            return
        ux, uy = (x2 - x1) / L, (y2 - y1) / L
        nx, ny = -uy, ux
        a = (x1 + nx * off, y1 + ny * off)
        b = (x2 + nx * off, y2 + ny * off)
        ext = 0.15 * abs(off) / max(abs(off), 1e-9) * min(abs(off), 0.3) if off else 0
        sgn = 1 if off >= 0 else -1
        self.line([(x1 + nx * off * 0.15, y1 + ny * off * 0.15), (a[0] + nx * sgn * 0.0, a[1] + ny * sgn * 0.0)], layer, 0.18)
        self.line([(x2 + nx * off * 0.15, y2 + ny * off * 0.15), b], layer, 0.18)
        self.line([a, b], layer, 0.18)
        self._add(k="tick", p=a, ang=math.atan2(uy, ux), layer=layer)
        self._add(k="tick", p=b, ang=math.atan2(uy, ux), layer=layer)
        if text is None:
            text = f"{L * 100:.0f}" if unit == "cm" else f"{L:.2f} m"
        ang = math.degrees(math.atan2(uy, ux))
        if ang > 90.1 or ang < -89.9:
            ang += 180
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        self._add(k="dimtext", p=mid, n=(nx * sgn, ny * sgn), s=text, size=size, rot=ang, layer=layer)

    def leader(self, p, q, s, size=6.5, layer="90-標註", ha=None):
        self.line([p, q], layer, 0.2)
        self.circle(p, 0.0, layer)
        self._add(k="dot", p=p, layer=layer)
        self.text(q, s, size=size, ha=ha or ("left" if q[0] >= p[0] else "right"), va="center", layer=layer)

    def extents(self):
        xs, ys = [], []
        for it in self.items:
            if it["k"] in ("line", "poly"):
                for x, y in it["pts"]:
                    xs.append(x); ys.append(y)
            elif it["k"] == "arc":
                for t in range(0, 13):
                    a = math.radians(it["a0"] + (it["a1"] - it["a0"]) * t / 12)
                    xs.append(it["c"][0] + it["r"] * math.cos(a)); ys.append(it["c"][1] + it["r"] * math.sin(a))
            elif it["k"] == "circle":
                xs += [it["c"][0] - it["r"], it["c"][0] + it["r"]]
                ys += [it["c"][1] - it["r"], it["c"][1] + it["r"]]
            elif it["k"] in ("text", "dimtext", "dot", "tick"):
                xs.append(it["p"][0]); ys.append(it["p"][1])
        return min(xs), min(ys), max(xs), max(ys)


# ───────────────────────── 輸出：matplotlib（PNG/SVG/PDF） ─────────────────────────
def _mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    fams = {f.name for f in font_manager.fontManager.ttflist}
    for cand in ("Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", "PingFang TC", "Noto Sans CJK JP", "Noto Sans CJK SC"):
        if cand in fams:
            matplotlib.rcParams["font.family"] = cand
            break
    else:
        print("⚠ 找不到中文字型（Noto Sans CJK TC 等），中文將無法正常顯示", file=sys.stderr)
    matplotlib.rcParams["svg.fonttype"] = "none"
    matplotlib.rcParams["pdf.fonttype"] = 42
    matplotlib.rcParams["axes.unicode_minus"] = False
    return plt


SCALES = [10, 20, 25, 30, 40, 50, 100, 150, 200, 250, 300, 400, 500, 600, 1000, 1200, 1500, 2000, 2500, 3000, 5000]
A3 = (420, 297)
DRAW_BOX = (12, 12, 300, 273)   # 繪圖區 mm（x, y, w, h）
TB_X = 318                     # 圖框標題欄起點 mm


def pick_scale(ext, box=DRAW_BOX, margin=1.06):
    w = (ext[2] - ext[0]) * margin
    h = (ext[3] - ext[1]) * margin
    for s in SCALES:
        if w * 1000 / s <= box[2] and h * 1000 / s <= box[3]:
            return s
    return SCALES[-1]


def render(cv, paths, title, dwg_no, scale=None, notes=(), project=None, legend=None, north=None, nts=False):
    """paths: dict(png=, svg=, pdf=) 或 PdfPages 物件（key 'pages'）"""
    plt = _mpl()
    from matplotlib.patches import Polygon as MPoly, Circle as MCircle, Arc as MArc
    ext = cv.extents()
    s = scale or pick_scale(ext)
    fig = plt.figure(figsize=(A3[0] / 25.4, A3[1] / 25.4), dpi=100)
    # 圖框
    fr = fig.add_axes([0, 0, 1, 1]); fr.set_xlim(0, A3[0]); fr.set_ylim(0, A3[1]); fr.axis("off")
    fr.add_patch(MPoly([(8, 8), (412, 8), (412, 289), (8, 289)], closed=True, fill=False, lw=1.2))
    fr.plot([TB_X - 2, TB_X - 2], [8, 289], color="k", lw=0.8)
    _title_block(fr, title, dwg_no, s, notes, project, nts)
    bx, by, bw, bh = DRAW_BOX
    ax = fig.add_axes([bx / A3[0], by / A3[1], bw / A3[0], bh / A3[1]])
    cx, cy = (ext[0] + ext[2]) / 2, (ext[1] + ext[3]) / 2
    W, H = bw * s / 1000, bh * s / 1000
    ax.set_xlim(cx - W / 2, cx + W / 2); ax.set_ylim(cy - H / 2, cy + H / 2)
    ax.set_aspect("equal"); ax.axis("off")
    m_per_pt = s / 1000 * 25.4 / 72 / 1000 * 1000  # 1 pt 在圖面對應之公尺
    for it in cv.items:
        col = it.get("color") or LAYERS.get(it.get("layer"), ("#000",))[0]
        ls = it.get("ls") or LAYERS.get(it.get("layer"), (0, 0, "solid"))[2]
        k = it["k"]
        if k == "line":
            xs, ys = zip(*it["pts"])
            ax.plot(xs, ys, color=col, lw=it["lw"] * 2.2, ls=ls, solid_capstyle="butt")
        elif k == "poly":
            ax.add_patch(MPoly(it["pts"], closed=True, fill=it["fill"] is not None, facecolor=it["fill"] or "none",
                               alpha=it["alpha"], edgecolor=col, lw=it["lw"] * 2.2, ls=ls, hatch=it["hatch"]))
            if it["fill"] is not None and it["alpha"] < 1:
                ax.add_patch(MPoly(it["pts"], closed=True, fill=False, edgecolor=col, lw=it["lw"] * 2.2, ls=ls))
        elif k == "circle":
            ax.add_patch(MCircle(it["c"], it["r"], fill=it["fill"] is not None, facecolor=it["fill"] or "none",
                                 alpha=it["alpha"], edgecolor=col, lw=it["lw"] * 2.2, ls=ls))
        elif k == "arc":
            ax.add_patch(MArc(it["c"], 2 * it["r"], 2 * it["r"], theta1=it["a0"], theta2=it["a1"], edgecolor=col, lw=it["lw"] * 2.2, ls=ls))
        elif k == "text":
            ax.text(it["p"][0], it["p"][1], it["s"], fontsize=it["size"], ha=it["ha"], va=it["va"], rotation=it["rot"],
                    color=it["color"], fontweight="bold" if it["bold"] else "normal", zorder=5)
        elif k == "dimtext":
            off = 4 * m_per_pt
            p = (it["p"][0] + it["n"][0] * off, it["p"][1] + it["n"][1] * off)
            ax.text(p[0], p[1], it["s"], fontsize=it["size"], ha="center", va="center", rotation=it["rot"], color="#333", zorder=5)
        elif k == "tick":
            L = 1.6 * s / 1000 * 1.0
            a = it["ang"] + math.pi / 4
            p = it["p"]
            ax.plot([p[0] - L * math.cos(a), p[0] + L * math.cos(a)], [p[1] - L * math.sin(a), p[1] + L * math.sin(a)], color="#333", lw=0.6)
        elif k == "dot":
            ax.plot([it["p"][0]], [it["p"][1]], marker="o", ms=1.6, color="#000")
    if legend:
        _legend(fr, legend)
    if north is not None:
        _north(fr, north)
    if not nts:
        _scalebar(fr, s)
    if "pages" in paths:
        paths["pages"].savefig(fig)
    for kind in ("png", "svg", "pdf"):
        if paths.get(kind):
            fig.savefig(paths[kind], dpi=200 if kind == "png" else 100)
    plt.close(fig)
    return s


def _title_block(fr, title, dwg_no, s, notes, project, nts):
    x0 = TB_X
    y = 284
    fr.text(x0, y, (project or {}).get("name", "（工程名稱）"), fontsize=9, fontweight="bold", va="top", wrap=True)
    y -= 12
    fr.text(x0, y, title, fontsize=12, fontweight="bold", va="top")
    y -= 9
    fr.text(x0, y, f"圖號：{dwg_no}    比例：{'NTS 不依比例' if nts else '1:' + str(s)}（A3）", fontsize=7, va="top")
    y -= 5
    fr.text(x0, y, f"日期：{datetime.date.today().isoformat()}    單位：公分（另註者除外）", fontsize=7, va="top")
    y -= 7
    fr.text(x0, y, "附註", fontsize=8, fontweight="bold", va="top")
    y -= 5
    for i, n in enumerate(notes, 1):
        for j, ln in enumerate(wrap_cjk(f"{i}. {n}", 31)):
            if y < 50:
                break
            fr.text(x0, y, ln if j == 0 else "   " + ln, fontsize=6.2, va="top")
            y -= 3.6
    # 簽認欄
    yb = 14
    for i, lab in enumerate(["設計", "繪圖", "校核", "審查"]):
        fr.plot([x0, 410], [yb + i * 7, yb + i * 7], color="k", lw=0.4)
        fr.text(x0 + 1, yb + i * 7 + 2, lab, fontsize=7)
    fr.plot([x0, 410], [yb + 28, yb + 28], color="k", lw=0.4)
    fr.text(x0, yb + 30, "【已核】網路條文核對 【待核】使用者核對\n【地方】地方規定 【示意】非法規值、依設計", fontsize=5.6, va="bottom")


def wrap_cjk(s, n):
    out, cur, w = [], "", 0.0
    for ch in s:
        cw = 0.55 if ord(ch) < 128 else 1.0
        if w + cw > n:
            out.append(cur); cur, w = "", 0.0
        cur += ch; w += cw
    if cur:
        out.append(cur)
    return out


def _legend(fr, legend):
    x0, y = 16, 283
    fr.text(x0, y, "圖例", fontsize=7.5, fontweight="bold", va="top")
    y -= 5
    from matplotlib.patches import Rectangle
    for lab, col, kind in legend:
        if kind == "line":
            fr.plot([x0, x0 + 7], [y - 1.2, y - 1.2], color=col, lw=1.6)
        elif kind == "dash":
            fr.plot([x0, x0 + 7], [y - 1.2, y - 1.2], color=col, lw=1.2, ls="--")
        else:
            fr.add_patch(Rectangle((x0, y - 2.6), 7, 2.8, facecolor=col, edgecolor="k", lw=0.3, alpha=0.55))
        fr.text(x0 + 9, y - 1.2, lab, fontsize=6, va="center")
        y -= 4.2


def _north(fr, deg):
    cx, cy, r = 300, 270, 7
    a = math.radians(90 - deg)
    tip = (cx + r * math.cos(a), cy + r * math.sin(a))
    l = (cx + r * 0.45 * math.cos(a + 2.5), cy + r * 0.45 * math.sin(a + 2.5))
    rr = (cx + r * 0.45 * math.cos(a - 2.5), cy + r * 0.45 * math.sin(a - 2.5))
    from matplotlib.patches import Polygon as MPoly
    fr.add_patch(MPoly([tip, l, (cx, cy), rr], closed=True, facecolor="k"))
    fr.add_patch(__import__("matplotlib.patches", fromlist=["Circle"]).Circle((cx, cy), r, fill=False, lw=0.6))
    fr.text(tip[0] + 2.5 * math.cos(a), tip[1] + 2.5 * math.sin(a), "N", ha="center", va="center", fontsize=8, fontweight="bold")


def _scalebar(fr, s):
    x0, y0 = 16, 15
    seg_m = next(v for v in (0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100) if v * 1000 / s >= 8)
    seg_mm = seg_m * 1000 / s
    for i in range(4):
        fr.add_patch(__import__("matplotlib.patches", fromlist=["Rectangle"]).Rectangle(
            (x0 + i * seg_mm, y0), seg_mm, 1.6, facecolor="k" if i % 2 == 0 else "w", edgecolor="k", lw=0.4))
        fr.text(x0 + i * seg_mm, y0 + 2.6, f"{seg_m * i:g}", fontsize=5.5, ha="center")
    fr.text(x0 + 4 * seg_mm, y0 + 2.6, f"{seg_m * 4:g} m", fontsize=5.5, ha="center")


# ───────────────────────── 輸出：DXF R12（免套件） ─────────────────────────
ACI = {name: v[1] for name, v in LAYERS.items()}


def write_dxf(cv, path, text_scale=1.0):
    out = []
    def g(c, v):
        out.append(f"{c}\n{v}")
    layer_names = sorted({it.get("layer", "0") for it in cv.items} | {"0"})
    g(0, "SECTION"); g(2, "HEADER"); g(9, "$ACADVER"); g(1, "AC1009"); g(9, "$DWGCODEPAGE"); g(3, "ANSI_950")
    g(9, "$INSUNITS"); g(70, 6); g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "TABLES")
    g(0, "TABLE"); g(2, "LTYPE"); g(70, 3)
    for nm, desc, pat in (("CONTINUOUS", "Solid", []), ("DASHED", "__ __", [1.0, -0.5]), ("DASHDOT", "_ . _", [1.0, -0.25, 0.0, -0.25])):
        g(0, "LTYPE"); g(2, nm); g(70, 0); g(3, desc); g(72, 65); g(73, len(pat)); g(40, sum(abs(p) for p in pat))
        for p in pat:
            g(49, p)
    g(0, "ENDTAB")
    g(0, "TABLE"); g(2, "LAYER"); g(70, len(layer_names))
    for nm in layer_names:
        lt = {"dashed": "DASHED", "dashdot": "DASHDOT"}.get(LAYERS.get(nm, (0, 0, "solid"))[2], "CONTINUOUS")
        g(0, "LAYER"); g(2, nm); g(70, 0); g(62, ACI.get(nm, 7)); g(6, lt)
    g(0, "ENDTAB")
    g(0, "TABLE"); g(2, "STYLE"); g(70, 1)
    g(0, "STYLE"); g(2, "CHT"); g(70, 0); g(40, 0.0); g(41, 1.0); g(50, 0.0); g(71, 0); g(42, 2.5); g(3, "txt.shx"); g(4, "chineset.shx")
    g(0, "ENDTAB"); g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "ENTITIES")
    def pl(pts, layer, closed):
        g(0, "POLYLINE"); g(8, layer); g(66, 1); g(10, 0); g(20, 0); g(30, 0); g(70, 1 if closed else 0)
        for x, y in pts:
            g(0, "VERTEX"); g(8, layer); g(10, f"{x:.4f}"); g(20, f"{y:.4f}"); g(30, 0)
        g(0, "SEQEND"); g(8, layer)
    for it in cv.items:
        k, ly = it["k"], it.get("layer", "0")
        if k == "line":
            pl(it["pts"], ly, False)
        elif k == "poly":
            pl(it["pts"], ly, True)
        elif k == "circle" and it["r"] > 0:
            g(0, "CIRCLE"); g(8, ly); g(10, f"{it['c'][0]:.4f}"); g(20, f"{it['c'][1]:.4f}"); g(30, 0); g(40, f"{it['r']:.4f}")
        elif k == "arc":
            g(0, "ARC"); g(8, ly); g(10, f"{it['c'][0]:.4f}"); g(20, f"{it['c'][1]:.4f}"); g(30, 0); g(40, f"{it['r']:.4f}"); g(50, it["a0"]); g(51, it["a1"])
        elif k in ("text", "dimtext"):
            h = it["size"] * 0.0003527 * text_scale
            hal = {"left": 0, "center": 1, "right": 2}.get(it.get("ha", "center"), 1)
            g(0, "TEXT"); g(8, ly); g(10, f"{it['p'][0]:.4f}"); g(20, f"{it['p'][1]:.4f}"); g(30, 0); g(40, f"{h:.4f}")
            g(1, it["s"].replace("\n", " ")); g(50, f"{it.get('rot', 0):.2f}"); g(7, "CHT")
            if hal:
                g(72, hal); g(11, f"{it['p'][0]:.4f}"); g(21, f"{it['p'][1]:.4f}"); g(31, 0)
    g(0, "ENDSEC"); g(0, "EOF")
    data = "\n".join(out) + "\n"
    with open(path, "wb") as f:
        f.write(data.encode("cp950", errors="replace"))


# ───────────────────────── 幾何工具 ─────────────────────────
def rect_pts(f):
    x, y, w, h = f["x"], f["y"], f["w"], f["h"]
    a = math.radians(f.get("rot", 0))
    c, s_ = math.cos(a), math.sin(a)
    return [(x + dx * c - dy * s_, y + dx * s_ + dy * c) for dx, dy in ((0, 0), (w, 0), (w, h), (0, h))]


def centroid(pts):
    return (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))


def area(pts):
    return abs(sum(pts[i][0] * pts[i - 1][1] - pts[i - 1][0] * pts[i][1] for i in range(len(pts)))) / 2


def pt_in_poly(p, poly):
    x, y = p; inside = False
    for i in range(len(poly)):
        x1, y1 = poly[i - 1]; x2, y2 = poly[i]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1 + 1e-12) + x1:
            inside = not inside
    return inside


def seg_dist(p, a, b):
    ax_, ay = a; bx, by = b; px, py = p
    dx, dy = bx - ax_, by - ay
    t = 0 if dx == dy == 0 else max(0, min(1, ((px - ax_) * dx + (py - ay) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - ax_ - t * dx, py - ay - t * dy)


def seg_seg_dist(a, b, c, d):
    def ccw(p, q, r):
        return (r[1] - p[1]) * (q[0] - p[0]) - (q[1] - p[1]) * (r[0] - p[0])
    if (ccw(a, b, c) * ccw(a, b, d) < 0) and (ccw(c, d, a) * ccw(c, d, b) < 0):
        return 0.0
    return min(seg_dist(a, c, d), seg_dist(b, c, d), seg_dist(c, a, b), seg_dist(d, a, b))


def poly_dist(P, Q):
    if any(pt_in_poly(p, Q) for p in P) or any(pt_in_poly(q, P) for q in Q):
        return 0.0
    return min(seg_seg_dist(P[i - 1], P[i], Q[j - 1], Q[j]) for i in range(len(P)) for j in range(len(Q)))


def poly_line_dist(P, line):
    if any(pt_in_poly(p, P) for p in line):
        return 0.0
    return min(seg_seg_dist(P[i - 1], P[i], line[j - 1], line[j]) for i in range(len(P)) for j in range(1, len(line)))


def offset_polyline(line, w):
    """回傳道路左右邊線構成之多邊形（近似）。"""
    L, Rr = [], []
    for i, p in enumerate(line):
        a = line[max(i - 1, 0)]; b = line[min(i + 1, len(line) - 1)]
        dx, dy = b[0] - a[0], b[1] - a[1]; n = math.hypot(dx, dy) or 1
        nx, ny = -dy / n * w / 2, dx / n * w / 2
        L.append((p[0] + nx, p[1] + ny)); Rr.append((p[0] - nx, p[1] - ny))
    return L + Rr[::-1]


# ───────────────────────── 設施類型 ─────────────────────────
FTYPE = {
    "office":   ("工務所", "04-臨時建物", "#9ecae1"),
    "toilet":   ("廁所", "04-臨時建物", "#c6dbef"),
    "shower":   ("浴室更衣", "04-臨時建物", "#c6dbef"),
    "rest":     ("休息室", "04-臨時建物", "#deebf7"),
    "guard":    ("警衛室", "04-臨時建物", "#9ecae1"),
    "lab":      ("試驗室", "04-臨時建物", "#9ecae1"),
    "store":    ("材料堆置場", "05-堆置加工", "#fdd0a2"),
    "rebar":    ("鋼筋加工場", "05-堆置加工", "#fdae6b"),
    "formwork": ("模板加工堆置", "05-堆置加工", "#fdae6b"),
    "precast":  ("預鑄構件堆置", "05-堆置加工", "#fdd0a2"),
    "waste":    ("廢棄物暫置", "11-環保設施", "#c7e9c0"),
    "soil":     ("土方暫置", "05-堆置加工", "#d9b38c"),
    "washer":   ("洗車台", "11-環保設施", "#a1d99b"),
    "sedtank":  ("沉砂池", "11-環保設施", "#74c476"),
    "panel":    ("總配電盤", "08-臨時用電", "#ffff99"),
    "subpanel": ("分電箱", "08-臨時用電", "#ffff99"),
    "water":    ("給水／儲水", "09-給排水", "#c6dbef"),
    "sign":     ("工程告示牌", "10-安全設施", "#fee391"),
    "fire":     ("滅火器", "10-安全設施", "#fb6a4a"),
    "firstaid": ("急救站", "10-安全設施", "#fcbba1"),
    "cctv":     ("監視器", "11-環保設施", "#bdbdbd"),
    "deck":     ("施工構台", "07-開挖擋土", "#d4b9da"),
    "ramp":     ("出土坡道", "07-開挖擋土", "#d4b9da"),
    "hoist":    ("營建用提升機", "06-機械起重", "#dadaeb"),
    "parking":  ("機具停放", "03-道路鋪面", "#e0e0e0"),
    "other":    ("其他", "04-臨時建物", "#f0f0f0"),
}
LIVING = {"office", "toilet", "shower", "rest", "guard", "lab", "firstaid"}
STOCK = {"store", "rebar", "formwork", "precast", "soil", "waste"}


def build_layout(site):
    cv = Canvas()
    S = site["site"]
    B = S["boundary"]
    cv.poly(B, "00-基地界線", 0.5)
    for rd in S.get("roads", []):
        poly = offset_polyline(rd["line"], rd["width"])
        cv.poly(poly, "03-道路鋪面", 0.25, fill="#eeeeee")
        mid = rd["line"][len(rd["line"]) // 2] if len(rd["line"]) > 2 else centroid(rd["line"])
        ang = math.degrees(math.atan2(rd["line"][-1][1] - rd["line"][0][1], rd["line"][-1][0] - rd["line"][0][0]))
        if ang > 90 or ang < -90:
            ang += 180
        dx, dy = rd["line"][-1][0] - rd["line"][0][0], rd["line"][-1][1] - rd["line"][0][1]
        Ln = math.hypot(dx, dy) or 1
        nx_, ny_ = -dy / Ln, dx / Ln
        cB = centroid(B)
        sg = -1 if (nx_ * (mid[0] - cB[0]) + ny_ * (mid[1] - cB[1])) < 0 else 1
        mid = (mid[0] + sg * nx_ * rd["width"] * 0.25, mid[1] + sg * ny_ * rd["width"] * 0.25)
        cv.text(mid, f"{rd['name']}（路寬 {rd['width']:g} m）", 8, rot=ang)
    # 圍籬（基地界線內縮 0.3 m 表示）
    cv.poly(_inset(B, 0.3), "01-圍籬", 0.7)
    if site.get("building"):
        b = site["building"]
        cv.poly(b["footprint"], "20-構造物", 0.6, fill="#ffffff", hatch="//")
        cb = centroid(b["footprint"]); cv.text((cb[0], cb[1] + 4.5), b.get("label", "新建構造物"), 8, bold=True)
    if site.get("excavation"):
        e = site["excavation"]
        cv.poly(e["polygon"], "07-開挖擋土", 0.6, ls="dashed")
        c = centroid(e["polygon"])
        cv.text((c[0], c[1] - 7), f"開挖範圍 深 {e['depth_m']:g} m（{e.get('shoring', '擋土型式依設計')}）", 6.5, color="#a0005a")
        if e.get("guardrail", True):
            cv.poly(_inset(e["polygon"], -0.5), "10-安全設施", 0.35, ls="dashed")
    for hr in site.get("haul_roads", []):
        poly = offset_polyline(hr["line"], hr["width"])
        cv.poly(poly, "03-道路鋪面", 0.3, fill="#d9d9d9", alpha=0.7)
        for i in range(1, len(hr["line"])):
            a, b = hr["line"][i - 1], hr["line"][i]
            cv.line([a, b], "03-道路鋪面", 0.2, ls="dashed")
        mid = hr["line"][1] if len(hr["line"]) > 1 else hr["line"][0]
        cv.text((mid[0] + 1.5, mid[1]), f"{hr.get('id', '')} 場內道路 寬{hr['width']:g}m {'單行' if hr.get('one_way') else '雙向'}・{hr.get('pavement', '鋪面依設計')}", 6, ha="left")
        if hr.get("one_way") and len(hr["line"]) >= 2:
            a, b = hr["line"][0], hr["line"][1]
            _arrow(cv, a, b)
    for f in site.get("facilities", []):
        t = FTYPE.get(f["type"], FTYPE["other"])
        pts = rect_pts(f)
        cv.poly(pts, t[1], 0.35, fill=t[2], alpha=0.85)
        lab = f.get("label", t[0])
        cv.text(centroid(pts), f"{f.get('id', '')}\n{lab}" if f.get("id") else lab, 6.2)
    for gte in site.get("gates", []):
        x, y = gte["at"]; w = gte["width"]; d = gte.get("dir", "S")
        horiz = d in ("S", "N")
        p1 = (x - w / 2, y) if horiz else (x, y - w / 2)
        p2 = (x + w / 2, y) if horiz else (x, y + w / 2)
        cv.line([p1, p2], "02-出入口", 1.2)
        lp = (x + (w / 2 + 1.5), y + (-1.8 if d == "S" else 1.8)) if horiz else (x + (-1.5 if d == "E" else 1.5), y + w / 2 + 1.5)
        cv.text(lp, f"{gte.get('id', '')} 大門 寬{w:g}m", 6.5, color="#c05000", ha="left" if horiz else ("right" if d == "E" else "left"))
        sign = {"S": (0, -1), "N": (0, 1), "E": (1, 0), "W": (-1, 0)}[d]
        _arrow(cv, (x - sign[0] * 3, y - sign[1] * 3), (x + sign[0] * 3, y + sign[1] * 3), layer="02-出入口")
    for cr in site.get("cranes", []):
        cv.circle(cr["at"], cr["radius"], "06-機械起重", 0.35, ls="dashed")
        cv.circle(cr["at"], 1.2, "06-機械起重", 0.5, fill="#9467bd")
        cv.text((cr["at"][0], cr["at"][1] - 3.2), f"{cr.get('label', cr.get('id', '起重機'))} R={cr['radius']:g}m", 6.5, color="#5b2c83")
    for pwl in site.get("power_lines", []):
        cv.line(pwl["line"], "08-臨時用電", 0.6, ls="dashdot", color="#d62728")
        cv.text(pwl["line"][0], f"架空電線 {pwl.get('voltage_kv', '?')} kV", 6, ha="left", color="#d62728")
    for pwr in site.get("power_routes", []):
        cv.line(pwr, "08-臨時用電", 0.4, ls="dashed")
    for dr in site.get("drains", []):
        cv.line(dr["line"], "09-給排水", 0.5)
        cv.text(dr["line"][0], dr.get("label", "截水溝"), 5.8, ha="left", color="#0b7285")
    # 基地尺寸
    for i in range(len(B)):
        a, b = B[i - 1], B[i]
        c = centroid(B)
        mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
        dx, dy = b[0] - a[0], b[1] - a[1]
        n = (-dy, dx); side = 1 if (n[0] * (mid[0] - c[0]) + n[1] * (mid[1] - c[1])) > 0 else -1
        cv.dim(a, b, 3.5 * side, unit="m", text=f"{math.hypot(dx, dy):.2f} m")
    return cv


def _inset(pts, d):
    """凸／簡單多邊形近似內縮（d>0 內縮）。"""
    c = centroid(pts)
    out = []
    n = len(pts)
    sgn = 1 if sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n)) > 0 else -1
    lines = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy) or 1
        nx, ny = -dy / L * sgn, dx / L * sgn
        lines.append(((a[0] + nx * d, a[1] + ny * d), (b[0] + nx * d, b[1] + ny * d)))
    for i in range(n):
        (p1, p2), (p3, p4) = lines[i - 1], lines[i]
        den = (p1[0] - p2[0]) * (p3[1] - p4[1]) - (p1[1] - p2[1]) * (p3[0] - p4[0])
        if abs(den) < 1e-9:
            out.append(p3); continue
        t = ((p1[0] - p3[0]) * (p3[1] - p4[1]) - (p1[1] - p3[1]) * (p3[0] - p4[0])) / den
        out.append((p1[0] + t * (p2[0] - p1[0]), p1[1] + t * (p2[1] - p1[1])))
    return out


def _arrow(cv, a, b, layer="03-道路鋪面"):
    dx, dy = b[0] - a[0], b[1] - a[1]; L = math.hypot(dx, dy) or 1
    ux, uy = dx / L, dy / L
    tip = b; s = min(1.6, L / 3)
    cv.line([a, b], layer, 0.4)
    cv.poly([tip, (tip[0] - ux * s - uy * s * 0.5, tip[1] - uy * s + ux * s * 0.5), (tip[0] - ux * s + uy * s * 0.5, tip[1] - uy * s - ux * s * 0.5)], layer, 0.2, fill="#555")


LEGEND = [
    ("基地界線", "#d62728", "dash"), ("施工圍籬", "#2ca02c", "line"), ("大門出入口", "#ff7f0e", "line"),
    ("場內道路", "#d9d9d9", "box"), ("臨時建物", "#9ecae1", "box"), ("堆置加工", "#fdae6b", "box"),
    ("環保設施", "#a1d99b", "box"), ("臨時用電", "#ffff99", "box"), ("開挖範圍", "#e377c2", "dash"),
    ("起重機作業半徑", "#9467bd", "dash"), ("截水溝", "#17becf", "line"), ("架空電線", "#d62728", "dash"),
]


# ───────────────────────── 佈置審查 ─────────────────────────
def eng_level(p):
    if p.get("engineering_level") in (1, 2):
        return p["engineering_level"], "使用者指定"
    t = p.get("type", "building")
    key = {"building": "lv1_building", "road": "lv1_road", "pipe": "lv1_pipe", "bridge": "lv1_bridge"}.get(t)
    if key and p.get("area_m2") and p.get("duration_months"):
        scale = p["area_m2"] * p["duration_months"]
        lv = 1 if scale >= R(key) else 2
        return lv, f"施工規模 {p['area_m2']:g} m² × {p['duration_months']:g} 月 = {scale:,.0f} m²·月 {'≥' if lv == 1 else '<'} {R(key):,} （{cite(key)}）"
    return None, "資料不足（需工程類別、面積、工期）"


def review(site):
    P = site.get("project", {})
    F = site.get("facilities", [])
    find = lambda t: [f for f in F if f["type"] == t]
    out = []

    def add(rid, status, item, finding, basis, action):
        out.append(dict(rule=rid, status=status, item=item, finding=finding, basis=basis, action=action))

    lv, why = eng_level(P)
    add("R00", "資訊" if lv else "缺資料", "營建工程分級", f"第{lv}級營建工程；{why}" if lv else why, "空污辦法 附表一", "" if lv else "補充工程類別、面積、工期")
    # R01 圍籬高度
    zone = P.get("air_zone")
    req = None
    if lv == 1:
        req, key = R("fence_h_lv1"), "fence_h_lv1"
    elif lv == 2:
        if zone == 3:
            req, key = R("fence_h_lv2_zone3"), "fence_h_lv2_zone3"
        elif zone in (1, 2):
            req, key = R("fence_h_lv2"), "fence_h_lv2"
    fh = site.get("fence", {}).get("height_m")
    if req is None:
        add("R01", "缺資料", "圍籬高度", "無法判定應設高度", "空污辦法 第6條、附表二", "補充工程分級與空氣品質防制區（1/2/3）")
    elif fh is None:
        add("R01", "缺資料", "圍籬高度", f"應設 {req:g} m 以上，方案未提供圍籬高度", cite(key), "於 site.json fence.height_m 填入")
    else:
        add("R01", "符合" if fh >= req else "不符", "圍籬高度", f"方案 {fh:g} m，應設 {req:g} m 以上", cite(key), "" if fh >= req else f"提高至 {req:g} m 以上")
    # R02 出入口洗車台＋沉砂池
    gates = site.get("gates", [])
    washers, seds = find("washer"), find("sedtank")
    lim = site.get("check", {}).get("washer_gate_max_m", 30)
    if not gates:
        add("R02", "缺資料", "出入口", "未標示大門出入口", "營造標準 第8條；空污辦法 第10條", "標示大門位置與寬度")
    for gte in gates:
        if not gte.get("haul", True):
            continue
        gp = gte["at"]
        dmin = min((min(seg_dist(gp, *e) for e in _edges(rect_pts(w))) for w in washers), default=None)
        if dmin is None:
            add("R02", "不符", f"{gte.get('id', '')} 洗車設備", "運輸車行出入口未設洗車台", cite("wash_basic"), "於出口內側設洗車台、防溢座、廢水收集坑與沉砂池")
        else:
            st = "符合" if dmin <= lim else "注意"
            add("R02", st, f"{gte.get('id', '')} 洗車設備", f"最近洗車台距出口 {dmin:.1f} m（檢核參數 {lim} m）", cite("wash_basic"), "" if st == "符合" else "洗車台宜移近出口，避免洗後車輛再行經裸露地")
    if washers and not seds:
        add("R03", "不符", "沉砂池", "設有洗車台但未配置沉砂池", cite("wash_basic"), "設具沉砂作用之沉砂池並接回收或放流")
    elif washers:
        add("R03", "符合", "沉砂池", f"沉砂池 {len(seds)} 處", cite("wash_basic"), "")
    # R04 場內道路寬度
    W = site.get("vehicle", {}).get("max_width_m")
    for hr in site.get("haul_roads", []):
        if W is None:
            add("R04", "缺資料", f"{hr.get('id', '')} 車道寬度", "未提供最大車寬", cite("road_two_way"), "於 vehicle.max_width_m 填入最大車寬")
            continue
        need = W + 1 if hr.get("one_way") else 2 * W + 1
        k = "road_one_way" if hr.get("one_way") else "road_two_way"
        add("R04", "符合" if hr["width"] >= need else "不符", f"{hr.get('id', '')} 車道寬度",
            f"{'單行' if hr.get('one_way') else '雙向'} 寬 {hr['width']:g} m，應 ≥ {need:g} m（最大車寬 {W:g} m）", cite(k),
            "" if hr["width"] >= need else f"加寬至 {need:g} m 或改單行並設迴車空間")
    # R05 堆置加工距開挖邊緣
    ex = site.get("excavation")
    if ex:
        H = ex["depth_m"]
        for f in F:
            if f["type"] in STOCK:
                d = poly_dist(rect_pts(f), ex["polygon"])
                st = "符合" if d >= H else ("不符" if d < R("guard_clear") else "注意")
                add("R05", st, f"{f.get('id', '')} {f.get('label', FTYPE[f['type']][0])}距開挖邊緣",
                    f"淨距 {d:.1f} m；開挖深 {H:g} m（不得堆積範圍＝H，待核）；護欄前淨空 {R('guard_clear'):g} m",
                    f"{cite('excav_stock')}；{cite('guard_clear')}", "" if st == "符合" else "外移或經擋土設計者核算超載並列入施工計畫")
        if H >= R("excav_shoring"):
            add("R06", "提醒", "擋土支撐", f"開挖深 {H:g} m ≥ {R('excav_shoring'):g} m，應設擋土支撐（{ex.get('shoring', '型式未提供')}）", cite("excav_shoring"), "擋土支撐依第73條設計、簽章並繪製施工圖")
        add("R07", "提醒", "開挖周邊護欄", "開挖周邊高差 2 m 以上應設護欄；並設安全上下設備", f"{cite('fall_height')}；{cite('guard_top')}", "依 D07、D09 詳圖設置")
    # R08 起重機
    for cr in site.get("cranes", []):
        hits = [f for f in F if f["type"] in LIVING and poly_dist(rect_pts(f), _circle_poly(cr["at"], cr["radius"])) == 0]
        if hits:
            add("R08", "注意", f"{cr.get('id', '')} 作業半徑涵蓋人員停留設施",
                "、".join(f"{h.get('id', '')}{h.get('label', FTYPE[h['type']][0])}" for h in hits),
                cite("crane_zone"), "移出半徑範圍；無法移出者設防護棚並規劃吊運路徑避開，或限制回轉範圍")
        else:
            add("R08", "符合", f"{cr.get('id', '')} 作業半徑", "未涵蓋工務所、廁所、休息室等人員停留設施", cite("crane_zone"), "")
        for pw in site.get("power_lines", []):
            d = min(seg_dist(cr["at"], pw["line"][i - 1], pw["line"][i]) for i in range(1, len(pw["line"])))
            if d <= cr["radius"]:
                add("R09", "不符", f"{cr.get('id', '')} 鄰近架空電線", f"電線距起重機中心 {d:.1f} m，在作業半徑 {cr['radius']:g} m 內（{pw.get('voltage_kv', '?')} kV）",
                    cite("crane_powerline"), "洽電業單位遷移或加裝絕緣防護，設限制回轉裝置並指派監視人員")
    # R10 臨時用電
    if not find("panel"):
        add("R10", "缺項", "臨時用電", "未配置總配電盤", cite("elcb_mid"), "配置總配電盤與分電箱，標示電源引接點")
    else:
        add("R10", "提醒", "臨時用電", f"總配電盤 {len(find('panel'))}、分電箱 {len(find('subpanel'))}；移動式電動機具分路設高敏感度高速型漏電斷路器（30 mA、0.1 s）", f"{cite('elcb_high')}；{cite('welder_vsd')}", "依 D11 單線圖標示漏電斷路器與接地")
    # R11 廁所
    wk = P.get("workers", {})
    if wk:
        m, fe = wk.get("male", 0), wk.get("female", 0)
        need_ms = math.ceil(m / R("toilet_m_seat")[0]) if m else 0
        need_mu = math.ceil(m / R("toilet_m_urinal")[0]) if m else 0
        need_fs = math.ceil(fe / R("toilet_f_seat")[0]) if fe else 0
        have = {"seats_m": 0, "urinals": 0, "seats_f": 0}
        for t in find("toilet"):
            for kk in have:
                have[kk] += t.get(kk, 0)
        ok = have["seats_m"] >= need_ms and have["urinals"] >= need_mu and have["seats_f"] >= need_fs
        add("R11", "符合" if ok else "不符", "廁所便器數",
            f"同時作業 男 {m}／女 {fe} 人：男便坑 需 {need_ms}（有 {have['seats_m']}）、男便池 需 {need_mu}（有 {have['urinals']}）、女便坑 需 {need_fs}（有 {have['seats_f']}）",
            f"{cite('toilet_m_seat')}；{cite('toilet_f_seat')}", "" if ok else "增設便器（流動廁所亦可）；男女分設並標示，女廁設加蓋桶")
        if fe and not any(t.get("seats_f") for t in find("toilet")):
            add("R11", "不符", "女用廁所", "有女性作業人員但未設女用廁所", cite("toilet_f_seat"), "男女廁所分別設置")
    else:
        add("R11", "缺資料", "廁所便器數", "未提供同時作業男女人數", cite("toilet_m_seat"), "於 project.workers 填入")
    # R12 告示牌
    signs = find("sign")
    for gte in gates:
        d = min((poly_dist(rect_pts(s_), [(gte["at"][0] - .1, gte["at"][1] - .1), (gte["at"][0] + .1, gte["at"][1] - .1), (gte["at"][0] + .1, gte["at"][1] + .1), (gte["at"][0] - .1, gte["at"][1] + .1)]) for s_ in signs), default=None)
        if gte.get("main", gte is gates[0]):
            if d is None:
                add("R12", "缺項", "工程告示牌／工地標示牌", "未配置", f"{cite('sign_air')}；{cite('sign_pcc')}", "於主要出入口明顯處設置")
            else:
                add("R12", "符合" if d <= 20 else "注意", "工程告示牌／工地標示牌", f"距 {gte.get('id', '')} {d:.1f} m", f"{cite('sign_air')}；{cite('sign_pcc')}", "")
    # R13 施工架
    sc = site.get("scaffold")
    if sc:
        h, a_ = sc.get("height_m", 0), sc.get("facade_area_m2", 0)
        hd, ad = R("scaf_design")
        if h >= hd and a_ >= ad:
            add("R13", "提醒", "施工架設計簽章", f"高 {h:g} m、立面 {a_:g} m² ≥ {hd:g} m 且 {ad:g} m²：須依結構力學設計、強度計算書與施工圖說簽章", cite("scaf_design"), "納入施工計畫，建立依圖施工查驗機制")
        if h >= R("scaf_supervisor"):
            add("R13", "提醒", "施工架組配作業主管", f"高 {h:g} m ≥ {R('scaf_supervisor'):g} m", cite("scaf_supervisor"), "指派施工架組配作業主管")
    if find("deck") or site.get("deck"):
        add("R14", "提醒", "施工構台", "施工構台須依結構力學設計並簽章；覆工板間隙 ≤ 3 cm；預留外伸撐座與材料堆置空間", f"{cite('scaf_design')}；{cite('deck_gap')}", "依 D05 詳圖")
    # R15 越界與重疊
    Bd = site["site"]["boundary"]
    for f in F:
        if not all(pt_in_poly(p, Bd) for p in rect_pts(f)):
            add("R15", "不符", f"{f.get('id', '')} 超出基地", f"{f.get('label', FTYPE[f['type']][0])} 部分位於基地界線外", cite("taipei_stock_inside"), "移入圍籬內；借用道路須經主管機關核准")
    for i in range(len(F)):
        for j in range(i + 1, len(F)):
            if F[i]["type"] in ("washer", "sedtank") and F[j]["type"] in ("washer", "sedtank"):
                continue
            if poly_dist(rect_pts(F[i]), rect_pts(F[j])) == 0:
                add("R15", "注意", "設施重疊", f"{F[i].get('id', '')} 與 {F[j].get('id', '')} 重疊", "幾何檢核", "調整位置")
    for hr in site.get("haul_roads", []):
        rp = offset_polyline(hr["line"], hr["width"])
        for f in F:
            if f["type"] in ("washer", "sedtank", "cctv", "sign", "hoist"):
                continue
            if any(seg_dist(p, hr["line"][i - 1], hr["line"][i]) < hr["width"] / 2 for p in rect_pts(f) + [centroid(rect_pts(f))] for i in range(1, len(hr["line"]))):
                add("R15", "不符", f"{f.get('id', '')} 占用場內道路", f"{f.get('label', FTYPE[f['type']][0])} 位於 {hr.get('id', '')} 車道範圍內", "幾何檢核；" + cite("road_two_way"), "移出車道或調整道路線形")
    if site.get("building"):
        for f in F:
            if f["type"] in LIVING | STOCK and poly_dist(rect_pts(f), site["building"]["footprint"]) == 0:
                add("R15", "不符", f"{f.get('id', '')} 與構造物重疊", f.get("label", ""), "幾何檢核", "移出構造物範圍或改分階段配置")
    # R16 監視、R17 逕流
    ca, cm, cs = R("cctv_trigger")
    if (P.get("area_m2", 0) >= ca and P.get("duration_months", 0) >= cm) or P.get("export_soil_m3", 0) >= cs:
        add("R16", "符合" if find("cctv") else "缺項", "攝錄影監視系統", "達設置規模", cite("cctv_trigger"), "" if find("cctv") else "出入口及洗車設施設監視器，影像保存 1 個月")
    if lv == 1 or P.get("eia"):
        add("R17", "提醒" if site.get("drains") else "缺項", "逕流廢水污染削減計畫", "第一級營建工程（或環評案）施工前報核；圖面標示遮雨、擋雨、導雨設施及沉砂池",
            cite("runoff_plan"), "" if site.get("drains") else "繪製截水溝、導水路徑與沉砂池（D12）")
    # R18 鋪面比例
    if lv:
        need = R("path_pave_lv1") if lv == 1 else R("path_pave_lv2")
        pr = P.get("paved_ratio")
        add("R18", "缺資料" if pr is None else ("符合" if pr >= need else "不符"), "車行路徑鋪設比例",
            f"應 ≥ {need:.0%}" + ("" if pr is None else f"，方案 {pr:.0%}"), cite("path_pave_lv1" if lv == 1 else "path_pave_lv2"), "" if (pr or 0) >= need else "提高鋪設比例")
    if not find("fire"):
        add("R19", "缺項", "滅火器", "未配置滅火器", "營造標準、設施規則（防火）", "於工務所、加工場、配電盤、易燃物附近配置")
    if not find("firstaid"):
        add("R19", "提醒", "急救設施", "未標示急救站", "職業安全衛生法規（急救）", "標示急救箱或急救站位置")
    return out


def _edges(pts):
    return [(pts[i - 1], pts[i]) for i in range(len(pts))]


def _circle_poly(c, r, n=48):
    return [(c[0] + r * math.cos(2 * math.pi * i / n), c[1] + r * math.sin(2 * math.pi * i / n)) for i in range(n)]


def write_review(site, items, d):
    P = site.get("project", {})
    order = {"不符": 0, "缺項": 1, "注意": 2, "缺資料": 3, "提醒": 4, "資訊": 5, "符合": 6}
    items = sorted(items, key=lambda x: (order.get(x["status"], 9), x["rule"]))
    cnt = {}
    for it in items:
        cnt[it["status"]] = cnt.get(it["status"], 0) + 1
    L = [f"# 總平面佈置審查意見｜{P.get('name', '（工程名稱）')}", "",
         f"審查日期：{datetime.date.today().isoformat()}　施工階段：{P.get('stage', '未提供')}　所在地：{P.get('city', '未提供')}", "",
         "## 一、案件狀況確認（含假設）", ""]
    lv, why = eng_level(P)
    L += [f"- 工程類別：{P.get('type', '未提供')}；分級：{('第%d級營建工程' % lv) if lv else '未定'}（{why}）",
          f"- 空氣品質防制區：{P.get('air_zone', '未提供')}；公共工程：{'是' if P.get('public_work') else '否／未提供'}；查核金額以上：{'是' if P.get('above_audit_amount') else '否／未提供'}",
          f"- 同時作業人數：男 {P.get('workers', {}).get('male', '?')}／女 {P.get('workers', {}).get('female', '?')}", "",
          "## 二、審查發現", "", "統計：" + "、".join(f"{k} {v}" for k, v in sorted(cnt.items(), key=lambda x: order.get(x[0], 9))), "",
          "| 規則 | 判定 | 項目 | 發現 | 依據 | 建議動作 |", "|---|---|---|---|---|---|"]
    for it in items:
        L.append(f"| {it['rule']} | {it['status']} | {it['item']} | {it['finding']} | {it['basis']} | {it['action']} |")
    L += ["", "## 三、風險與複核提示", "",
          "- 【待核】標記之規則值未能以法規原文確認，正式使用前請以全國法規資料庫現行條文核對（見 verify_list.csv）。",
          "- 【地方】標記為地方規定（如臺北市、新北市、桃園市），工程所在地不同時改依當地規定。",
          "- 基坑周邊堆載、施工構台、高度 7 m 以上施工架、塔式起重機基礎與附牆，須由專任工程人員或執業技師設計簽章，本審查不取代結構計算。",
          "- 臨時用電負載與配電設計、消防設備數量，須由合格電機與消防人員確認。",
          "- 本審查不取代契約圖說、施工計畫書、交通維持計畫及主管機關核定文件。", ""]
    open(os.path.join(d, "review.md"), "w", encoding="utf-8").write("\n".join(L))
    json.dump(items, open(os.path.join(d, "review.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return cnt


# ───────────────────────── 構造詳圖 ─────────────────────────
def _p(params, key, default, label=None):
    """取參數；未提供者回傳 (值, True＝示意)。"""
    if key in params:
        try:
            return float(params[key]), False
        except (TypeError, ValueError):
            return params[key], False
    return default, True


def _sx(v, demo):
    return f"{v * 100:.0f}" + ("（示意）" if demo else "")


def guardrail_elev(cv, x0, y0, L, post=None, toe=True, layer="10-安全設施", dims=True):
    top, gap, td, sp = R("guard_top"), R("guard_gap"), R("guard_toe"), post or R("guard_post_steel")
    n = max(1, math.ceil(L / sp))
    sp_ = L / n
    mid = top / 2
    for i in range(n + 1):
        x = x0 + i * sp_
        cv.line([(x, y0), (x, y0 + top + 0.05)], layer, 0.5)
    cv.line([(x0, y0 + top), (x0 + L, y0 + top)], layer, 0.6)
    cv.line([(x0, y0 + mid), (x0 + L, y0 + mid)], layer, 0.45)
    if toe:
        cv.rect(x0, y0, L, td, layer=layer, lw=0.3, fill="#ffd54f")
    if dims:
        cv.dim((x0 + L, y0), (x0 + L, y0 + top), -0.35, f"≥{top * 100:.0f}")
        cv.dim((x0 + L, y0 + mid), (x0 + L, y0 + top), -0.75, f"≤{gap * 100:.0f}")
        cv.dim((x0, y0), (x0 + sp_, y0), -0.35, f"≤{sp * 100:.0f}")
    return mid


def ground(cv, x0, x1, y=0, layer="20-構造物"):
    cv.line([(x0, y), (x1, y)], layer, 0.5)
    k = x0
    while k < x1:
        cv.line([(k, y), (k - 0.12, y - 0.12)], layer, 0.15)
        k += 0.25


def D01(pr, site):
    lv, _ = eng_level(site.get("project", {})) if site else (None, "")
    zone = (site or {}).get("project", {}).get("air_zone")
    if "h" in pr:
        h, hdemo, hsrc = float(pr["h"]), False, "使用者指定"
    elif lv == 1:
        h, hdemo, hsrc = R("fence_h_lv1"), False, cite("fence_h_lv1")
    elif lv == 2 and zone in (1, 2):
        h, hdemo, hsrc = R("fence_h_lv2"), False, cite("fence_h_lv2")
    else:
        h, hdemo, hsrc = R("fence_h_lv1"), False, cite("fence_h_lv1") + "（未提供分級，以第一級繪製）"
    sp, spd = _p(pr, "post", 2.0)
    curb = R("fence_curb_large") if h >= 3 else R("fence_curb_small")
    cv = Canvas()
    L = 3 * sp
    ground(cv, -0.5, L + 0.5)
    cv.rect(0, 0, L, curb[0], layer="20-構造物", lw=0.4, fill="#cccccc", hatch="..")
    for i in range(4):
        x = i * sp
        cv.rect(x - 0.03, curb[0], 0.06, h - curb[0], layer="01-圍籬", lw=0.4, fill="#777777")
        cv.circle((x, h + 0.12), 0.08, "10-安全設施", fill="#ff3b30")
    for i in range(3):
        x = i * sp
        cv.rect(x + 0.03, curb[0], sp - 0.06, h - curb[0], layer="01-圍籬", lw=0.3, fill="#c7e9c0", alpha=0.6)
        k = x + 0.15
        while k < x + sp - 0.05:
            cv.line([(k, curb[0]), (k, h)], "01-圍籬", 0.12)
            k += 0.15
    cv.text((L / 2, h / 2 + 0.3), "槽型鍍鋅鋼板或鋁板（全阻隔式）", 7)
    cv.dim((0, 0), (0, h), 0.45, f"{h * 100:.0f}")
    cv.dim((L, 0), (L, curb[0]), -0.4, f"≥{curb[0] * 100:.0f}")
    cv.dim((0, 0), (sp, 0), -0.45, _sx(sp, spd))
    cv.leader((sp, h + 0.12), (sp + 0.6, h + 0.6), "警示燈（地方規定間距 2.25～6 m）")
    cv.text((L / 2, -0.85), "立面圖", 9, bold=True)
    # 斷面
    ox = L + 2.2
    ground(cv, ox - 1.2, ox + 2.2)
    cv.rect(ox, 0, curb[1], curb[0], layer="20-構造物", lw=0.4, fill="#cccccc", hatch="..")
    cv.rect(ox + curb[1] / 2 - 0.03, curb[0], 0.06, h - curb[0], layer="01-圍籬", lw=0.4, fill="#777777")
    cv.rect(ox + curb[1] / 2 - 0.05, 0.0, 0.1, curb[0], layer="01-圍籬", lw=0.2, ls="dashed")
    cv.line([(ox + curb[1] / 2, h * 0.7), (ox + curb[1] / 2 + h * 0.55, 0.0)], "01-圍籬", 0.4)
    cv.rect(ox + curb[1] / 2 + h * 0.55 - 0.2, -0.3, 0.4, 0.3, layer="20-構造物", lw=0.3, fill="#bbbbbb")
    cv.dim((ox, 0), (ox + curb[1], 0), -0.35, f"≥{curb[1] * 100:.0f}")
    cv.dim((ox - 0.3, 0), (ox - 0.3, h), 0.3, f"{h * 100:.0f}")
    cv.leader((ox + curb[1] / 2 + h * 0.3, h * 0.33), (ox + 1.6, h * 0.65), "斜撐與地錨（依設計）")
    cv.leader((ox + curb[1], curb[0] * 0.6), (ox + 1.6, 0.6), "防溢座（防止基地用水溢流）")
    cv.text((ox + 0.5, -0.85), "斷面圖", 9, bold=True)
    notes = [f"圍籬高度 {h:g} m：{hsrc}",
             f"道路轉角或轉彎處 {R('fence_corner_semi'):g} m 內得設半阻隔式（離地 {R('fence_semi_solid_h') * 100:.0f} cm 以上網狀）：{cite('fence_corner_semi')}",
             f"圍籬定著地面並設防溢座：{cite('fence_h_lv1').split('【')[0]}【已核】",
             f"防溢座 {curb[0] * 100:.0f}×{curb[1] * 100:.0f} cm：{cite('fence_curb_large' if h >= 3 else 'fence_curb_small')}",
             f"面板厚 {R('fence_panel_t')} mm 以上：{cite('fence_panel_t')}",
             f"警示燈間距 2.25～6 m：{cite('fence_lamp_spacing')}",
             "立柱間距、埋入深度、斜撐與地錨依設計（示意值非法規值），抗風能力由設計者檢核。",
             f"工作場所周圍設固定式圍籬並設警告標示：{cite('fence_general')}"]
    return cv, "D01 施工圍籬構造詳圖", notes


def D02(pr, site):
    w, wd = _p(pr, "w", 8.0)
    h, hd = _p(pr, "h", R("fence_h_lv1"))
    cv = Canvas()
    ground(cv, -1.2, w + 1.2)
    for x in (-0.25, w):
        cv.rect(x, 0, 0.25, h + 0.2, layer="02-出入口", lw=0.5, fill="#888888")
    half = w / 2
    for x in (0, half):
        cv.rect(x + 0.02, 0.08, half - 0.04, h - 0.08, layer="02-出入口", lw=0.45, fill="#fdd0a2", alpha=0.7)
        cv.line([(x + 0.02, 0.08), (x + half - 0.02, h)], "02-出入口", 0.2)
        cv.line([(x + half - 0.02, 0.08), (x + 0.02, h)], "02-出入口", 0.2)
        cv.circle((x + 0.25, 0.08), 0.07, "02-出入口")
        cv.circle((x + half - 0.25, 0.08), 0.07, "02-出入口")
    cv.line([(-0.3, R("gate_solid_h")), (w + 0.3, R("gate_solid_h"))], "91-尺寸", 0.2, ls="dashed")
    cv.text((w / 2, R("gate_solid_h") + 0.15), f"{R('gate_solid_h') * 100:.0f} cm 以下不得透空（地方）", 6.5)
    cv.dim((0, 0), (w, 0), -0.45, _sx(w, wd))
    cv.dim((w + 0.25, 0), (w + 0.25, h), -0.4, _sx(h, hd))
    cv.text((w / 2, h + 0.7), "施工大門 立面圖（雙扇滑輪平開）", 9, bold=True)
    oy = -3.2
    cv.line([(-1, oy), (0, oy)], "01-圍籬", 0.6); cv.line([(w, oy), (w + 1, oy)], "01-圍籬", 0.6)
    cv.line([(0, oy), (half * 0.0 + 0.0, oy - half)], "02-出入口", 0.5)
    cv.line([(w, oy), (w, oy - half)], "02-出入口", 0.5)
    cv.arc((0, oy), half, 270, 360, "02-出入口", 0.2, ls="dashed")
    cv.arc((w, oy), half, 180, 270, "02-出入口", 0.2, ls="dashed")
    cv.text((w / 2, oy + 0.5), "道路側", 7)
    cv.text((w / 2, oy - half + 0.3), "基地內（門扇向內開啟）", 7)
    cv.text((w / 2, oy - half - 0.8), "平面圖", 9, bold=True)
    notes = [f"門寬依最大進出車輛與轉彎軌跡決定（示意 {w:g} m，依設計）。",
             f"門高同圍籬高度；{R('gate_solid_h') * 100:.0f} cm 以下不得透空、鐵門厚 1.2 mm 以上：{cite('gate_solid_h')}",
             "除車輛出入外隨時關閉；門扇向基地內開啟，不得占用道路。",
             f"車輛出入口設交通號誌、標示或柵欄；不足時置交通引導人員：{cite('traffic_sign')}",
             "大門處設警示燈與照明；門柱基礎依設計。"]
    return cv, "D02 施工大門構造詳圖", notes


def D03(pr, site):
    tw, twd = _p(pr, "truck_w", 2.5)
    auto = str(pr.get("auto", "0")) in ("1", "true", "True")
    W = max(float(pr.get("w", 0) or 0), (R("wash_auto_width") * tw) if auto else 0) or 3.5
    wdemo = "w" not in pr and not auto
    L, Ld = _p(pr, "l", 8.0)
    cv = Canvas()
    cv.rect(0, 0, L, W, layer="11-環保設施", lw=0.5, fill="#e5f5e0")
    cv.rect(-0.2, -0.2, L + 0.4, 0.2, layer="20-構造物", lw=0.3, fill="#aaaaaa")
    cv.rect(-0.2, W, L + 0.4, 0.2, layer="20-構造物", lw=0.3, fill="#aaaaaa")
    for i in range(int(L / 0.5) + 1):
        cv.circle((i * 0.5, -0.32), 0.04, "09-給排水"); cv.circle((i * 0.5, W + 0.32), 0.04, "09-給排水")
    cv.rect(L + 0.2, -0.2, 0.6, W + 0.4, layer="09-給排水", lw=0.4, fill="#c6dbef", hatch="||")
    cv.text((L + 0.5, W / 2), "廢水\n收集坑", 6)
    sx = L + 1.6
    cw = 1.2
    for i in range(3):
        cv.rect(sx + i * cw, -0.3, cw, W + 0.6, layer="11-環保設施", lw=0.45, fill="#9ecae1" if i < 2 else "#c6dbef")
        cv.text((sx + i * cw + cw / 2, W / 2), ["一次\n沉砂", "二次\n沉砂", "清水\n回收"][i], 6.5)
    cv.line([(L + 0.8, W / 2), (sx, W / 2)], "09-給排水", 0.5)
    cv.leader((sx + 3 * cw, W * 0.8), (sx + 3 * cw + 1.2, W + 1.0), "回收泵浦→沖洗用水")
    cv.leader((sx + 3 * cw, W * 0.2), (sx + 3 * cw + 1.2, -0.8), "放流（符合放流水標準）")
    cv.text((L / 2, W / 2), "洗車平台（混凝土鋪面，向收集坑洩水）", 7)
    cv.dim((0, -0.2), (L, -0.2), -0.7, _sx(L, Ld))
    cv.dim((0, 0), (0, W), 0.6, (f"≥{R('wash_auto_width'):g}×車寬" if auto else _sx(W, wdemo)))
    cv.leader((L * 0.3, W + 0.2), (L * 0.3, W + 1.1), "防溢座（四周）")
    cv.leader((1.0, -0.32), (1.0, -1.4), "兩側沖洗噴嘴" + (f"（間隔 ≤{R('wash_auto_nozzle')[0] * 100:.0f} cm、水壓 {R('wash_auto_nozzle')[1]} kg/cm²）" if auto else "（間距依設計）"))
    cv.text((L / 2 + 2, W + 2.0), "洗車台及沉砂池 平面圖", 9, bold=True)
    oy = -4.8
    ground(cv, sx - 0.6, sx + 3 * cw + 0.6, oy)
    dep = 1.2
    cv.rect(sx, oy - dep, 3 * cw, dep, layer="11-環保設施", lw=0.5)
    for i in (1, 2):
        x = sx + i * cw
        cv.line([(x, oy - dep), (x, oy - dep * (0.25 if i == 1 else 0.35))], "11-環保設施", 0.5)
    cv.rect(sx, oy - dep, 3 * cw, dep * 0.7, layer="09-給排水", lw=0.1, fill="#c6dbef", alpha=0.5)
    cv.dim((sx + 3 * cw, oy - dep), (sx + 3 * cw, oy), -0.4, "依設計")
    cv.text((sx + 1.5 * cw, oy - dep - 0.6), "沉砂池斷面（溢流隔牆）", 9, bold=True)
    notes = [f"洗車台四周設防溢座、廢水收集坑及具沉砂作用之沉砂池：{cite('wash_basic')}",
             "車輛離場須清洗車體及輪胎，不得附著污泥或造成路面色差。",
             (f"自動洗車（區域開發、疏濬工程）：台寬 > {R('wash_auto_width')} 倍車寬；水槽深 ≥ {R('wash_auto_tank')[0] * 100:.0f} cm、水深 ≥ {R('wash_auto_tank')[1] * 100:.0f} cm；噴口間隔 ≤ {R('wash_auto_nozzle')[0] * 100:.0f} cm：{cite('wash_auto_width')}" if auto else "非區域開發／疏濬工程者，平台長寬、沉砂池容量依設計（示意值）。"),
             "沉砂池定期清淤並記錄；放流前符合放流水標準。",
             f"洗車台至主要道路之車行路徑應鋪設：{cite('path_pave_lv2')}"]
    return cv, "D03 洗車台及沉砂池詳圖", notes


def D04(pr, site):
    W, Wd = _p(pr, "w", 2.4)
    H, Hd = _p(pr, "h", 1.8)
    leg, legd = _p(pr, "leg", 1.0)
    P = (site or {}).get("project", {})
    cv = Canvas()
    ground(cv, -0.8, W + 0.8)
    for x in (0.2, W - 0.2):
        cv.rect(x - 0.05, 0, 0.1, leg + H, layer="20-構造物", lw=0.4, fill="#888888")
        cv.rect(x - 0.25, -0.5, 0.5, 0.5, layer="20-構造物", lw=0.3, ls="dashed")
    cv.rect(0, leg, W, H, layer="10-安全設施", lw=0.6, fill="#fffbe6")
    rows = [("工程名稱", P.get("name", "")), ("主辦機關", ""), ("監造單位", ""), ("承攬廠商", ""), ("工期", ""), ("工程經費", ""),
            ("空污費管制編號", ""), ("工地負責人／電話", ""), ("環保局公害檢舉電話", "")]
    if P.get("above_audit_amount", True):
        rows += [("機關督導工務所／監造工務所電話", ""), ("專任工程人員／品管／安衛 姓名電話", "")]
    rh = H * 0.78 / len(rows)
    cv.text((W / 2, leg + H - 0.12), "工 程 告 示 牌", 10, bold=True)
    for i, (k, v) in enumerate(rows):
        y = leg + H - 0.25 - (i + 1) * rh
        cv.line([(0.05, y), (W * 0.62, y)], "10-安全設施", 0.15)
        cv.text((0.1, y + rh / 2), k, 5.4, ha="left")
        cv.text((W * 0.33, y + rh / 2), v, 5.4, ha="left")
    cv.rect(W * 0.65, leg + 0.15, W * 0.32, H * 0.72, layer="10-安全設施", lw=0.3, ls="dashed")
    cv.text((W * 0.81, leg + 0.15 + H * 0.36), "工程透視圖\n或平面位置圖", 6)
    cv.dim((0, leg), (W, leg), -0.35 - leg, _sx(W, Wd))
    cv.dim((W, leg), (W, leg + H), -0.35, _sx(H, Hd))
    cv.dim((W, 0), (W, leg), -0.35, _sx(leg, legd))
    cv.text((W / 2, -0.9), "工程告示牌兼工地標示牌 立面圖", 9, bold=True)
    notes = [f"工地標示牌應載明空污費管制編號、工地負責人姓名電話、環保局公害檢舉電話：{cite('sign_air')}",
             f"查核金額以上工程增列督導及監造工務所電話、專任工程人員、品管、安衛人員姓名電話、透視圖或平面位置圖：{cite('sign_pcc')}",
             "告示牌尺寸、材料、字體依契約圖說（示意值）；設於主要出入口明顯處。",
             f"臺北市開挖面積 3000 m² 以上且多面臨路者，每一鄰向距出入口每 50 m 增設：{cite('sign_taipei_extra')}",
             "竣工驗收合格前拆除，或經工程司同意後拆除。"]
    return cv, "D04 工程告示牌詳圖", notes


def D05(pr, site):
    span, sd = _p(pr, "span", 6.0)
    bays = int(float(pr.get("bays", 3)))
    hh, hhd = _p(pr, "h", 2.0)
    cv = Canvas()
    Ltot = span * bays
    top = hh
    ground(cv, -1, Ltot + 1, -6)
    cv.text((Ltot + 0.8, -5.6), "開挖面", 6.5, ha="left")
    cv.line([(-2, top), (Ltot + 2, top)], "20-構造物", 0.2, ls="dashed")
    cv.text((-2, top + 0.3), "原地面", 6.5, ha="left")
    for i in range(bays + 1):
        x = i * span
        cv.rect(x - 0.15, -8, 0.3, top + 8, layer="07-開挖擋土", lw=0.4, fill="#bdbdbd")
    cv.rect(0, top, Ltot, 0.6, layer="07-開挖擋土", lw=0.5, fill="#9e9ac8")
    cv.text((Ltot / 2, top + 0.3), "主梁（H 型鋼，依設計）", 6.5)
    cv.rect(0, top + 0.6, Ltot, 0.2, layer="07-開挖擋土", lw=0.4, fill="#dadaeb")
    for i in range(int(Ltot / 1.0)):
        cv.line([(i * 1.0, top + 0.6), (i * 1.0, top + 0.8)], "07-開挖擋土", 0.15)
    guardrail_elev(cv, 0, top + 0.8, Ltot, dims=True)
    cv.text((Ltot / 2, -8.6), "中間柱／支柱（依土質埋設或加墊板）", 7)
    cv.leader((1.0, top + 0.7), (2.6, top + 2.6), f"覆工板（間隙 ≤ {R('deck_gap') * 100:.0f} cm）")
    cv.dim((0, -8), (span, -8), -0.5, _sx(span, sd))
    cv.text((Ltot / 2, top + 3.0), "施工構台 縱斷面圖", 9, bold=True)
    notes = [f"施工構台須依結構力學設計，備施工圖說及強度計算書並簽章，建立依圖施工查驗機制：{cite('scaf_design')}",
             f"覆工板間隙 ≤ {R('deck_gap') * 100:.0f} cm；支柱依土質埋設或加墊板，連接部位以螺栓或鉚釘固定：{cite('deck_gap')}",
             "構台寬度足供機具運轉，並預留起重機外伸撐座與材料堆置場地；載重標示牌設於明顯處。",
             f"構台邊緣設護欄：上欄杆 ≥ {R('guard_top') * 100:.0f} cm、開口 ≤ {R('guard_gap') * 100:.0f} cm、腳趾板：{cite('guard_top')}",
             "跨距、支柱間距、梁型號與構台高度均依設計（示意值）。"]
    return cv, "D05 施工構台詳圖", notes


def D06(pr, site):
    H, Hd = _p(pr, "depth", 6.0)
    n, nd = _p(pr, "slope_n", 6.0)
    W, Wd = _p(pr, "w", 6.0)
    cv = Canvas()
    Lr = H * n
    cv.line([(-4, 0), (0, 0), (Lr, -H), (Lr + 6, -H)], "20-構造物", 0.6)
    cv.poly([(0, 0), (Lr, -H), (Lr, -H - 0.3), (0, -0.3)], layer="03-道路鋪面", lw=0.3, fill="#d9d9d9", hatch="..")
    for i in range(0, int(Lr / 2.5) + 1):
        x = i * 2.5
        y = -x / n
        cv.line([(x, y), (x, y + R("guard_top"))], "10-安全設施", 0.4)
    cv.line([(0, R("guard_top")), (Lr, -H + R("guard_top"))], "10-安全設施", 0.5)
    cv.line([(0, R("guard_top") / 2), (Lr, -H + R("guard_top") / 2)], "10-安全設施", 0.4)
    cv.dim((0, -H - 0.3), (Lr, -H - 0.3), -0.6, f"{Lr * 100:.0f}" + ("（示意）" if (Hd or nd) else ""))
    cv.dim((Lr + 6, -H), (Lr + 6, 0), -0.5, _sx(H, Hd))
    cv.text((Lr * 0.45, -H * 0.45 - 1.0), f"坡度 1:{n:g}" + ("（示意，依設計）" if nd else "") + "　鋪面：鋼板／混凝土／粗級配", 7, rot=-math.degrees(math.atan(1 / n)))
    cv.text((-2, 0.5), "地面（開挖頂）", 7)
    cv.text((Lr + 3, -H + 0.5), "開挖底", 7)
    cv.text((Lr / 2, 2.5), "出土坡道 縱斷面圖", 9, bold=True)
    ox = Lr + 12
    ground(cv, ox - 1, ox + W + 1, 0)
    cv.rect(ox, -0.3, W, 0.3, layer="03-道路鋪面", lw=0.3, fill="#d9d9d9")
    for x in (ox, ox + W):
        cv.line([(x, 0), (x, R("guard_top"))], "10-安全設施", 0.5)
    cv.dim((ox, -0.3), (ox + W, -0.3), -0.5, _sx(W, Wd))
    cv.text((ox + W / 2, 2.5), "橫斷面圖", 9, bold=True)
    notes = ["坡度、寬度、轉彎半徑與鋪面依最大出土車輛性能設計（示意值，非法規值）。",
             f"自設道路坡度不得使車輛機械有滑下可能；邊緣及開口設防止翻落設施：{cite('road_edge')}",
             f"坡道兩側高差 2 m 以上設護欄（上欄杆 ≥ {R('guard_top') * 100:.0f} cm）：{cite('fall_height')}",
             f"單行坡道寬 ≥ 車寬＋1 m，雙向 ≥ 2×車寬＋1 m：{cite('road_two_way')}",
             "坡道鋪面計入車行路徑鋪設比例；坡底設集水坑抽排。"]
    return cv, "D06 出土坡道詳圖", notes


def D07(pr, site):
    H, Hd = _p(pr, "depth", float((site or {}).get("excavation", {}).get("depth_m", 10)))
    cv = Canvas()
    cv.rect(-0.8, -H - 3, 0.8, H + 3, layer="07-開挖擋土", lw=0.5, fill="#bdbdbd", hatch="//")
    cv.line([(-max(H, 2) - 4, 0), (-0.8, 0)], "20-構造物", 0.5)
    cv.line([(0, -H), (8, -H)], "20-構造物", 0.5)
    for k in range(3):
        y = -1.5 - k * (H - 2) / 2.5
        cv.line([(0, y), (8, y)], "07-開挖擋土", 0.5)
        cv.text((6.5, y + 0.25), f"第{k + 1}層支撐", 6)
    gx = -0.45
    cv.rect(gx - 0.02, 0, 0.04, R("guard_top") + 0.05, layer="10-安全設施", lw=0.4, fill="#d62728")
    for yy in (R("guard_top"), R("guard_top") / 2):
        cv.circle((gx + 0.04, yy), 0.03, "10-安全設施", fill="#d62728")
    cv.rect(gx + 0.06, 0, 0.03, R("guard_toe"), layer="10-安全設施", lw=0.3, fill="#ffd54f")
    cv.dim((gx + 0.2, 0), (gx + 0.2, R("guard_top")), -0.4, f"≥{R('guard_top') * 100:.0f}")
    cv.leader((gx, R("guard_top")), (1.5, R("guard_top") + 1.6), f"護欄：上欄杆 ≥{R('guard_top') * 100:.0f}、開口 ≤{R('guard_gap') * 100:.0f}、腳趾板（D09）")
    cv.poly([(-0.8 - H, 0), (-0.8, 0), (-0.8, 0.05), (-0.8 - H, 0.05)], layer="10-安全設施", lw=0.2, fill="#fb6a4a", alpha=0.35)
    cv.dim((-0.8 - H, 0), (-0.8, 0), -0.6, f"H＝{H * 100:.0f}（待核）")
    cv.text((-0.8 - H / 2, 0.6), "土石、材料不得堆積範圍（開挖面上方，寬度＝開挖深 H，待核）", 6.5, color="#b30000")
    cv.rect(-0.8 - 2.2, -0.4, 0.4, 0.4, layer="09-給排水", lw=0.4)
    cv.text((-0.8 - 2.0, -0.75), "截水溝", 6)
    cv.dim((8, -H), (8, 0), -0.6, _sx(H, Hd))
    cv.text((-0.4, -H - 3.6), "擋土壁（型式依設計）", 7)
    cv.text((3, 3.2), "開挖周邊安全設施 斷面圖", 9, bold=True)
    notes = [f"開挖深 1.5 m 以上且有勞工進入，應設擋土支撐：{cite('excav_shoring')}",
             "擋土支撐依地質資料設計、繪製詳細圖樣並由專任工程人員或執業技師簽章（營造標準第73條）【已核】",
             f"開挖出之土石不得堆積於開挖面上方；與開挖面高度等值之坡肩寬度範圍：{cite('excav_stock')}",
             f"開挖周邊高差 2 m 以上設護欄：{cite('fall_height')}",
             f"護欄前 {R('guard_clear'):g} m 內不得堆放物料、停放機械：{cite('guard_clear')}",
             "周邊設截水溝防止地表水流入；設安全上下設備（樓梯塔）。",
             "基坑周邊加工場、堆載及構台荷重須經擋土設計者確認。"]
    return cv, "D07 開挖周邊護欄及擋土詳圖", notes


def D08(pr, site):
    Hs, Hsd = _p(pr, "h", 15.0)
    Ls, Lsd = _p(pr, "l", 15.0)
    lift, lfd = _p(pr, "lift", 1.7)
    bay, byd = _p(pr, "bay", 1.829)
    cv = Canvas()
    ground(cv, -1, Ls + 1)
    nb = max(1, int(Ls / bay)); nl = max(1, int(Hs / lift))
    for i in range(nb + 1):
        cv.line([(i * bay, 0), (i * bay, nl * lift + 1.0)], "10-安全設施", 0.35)
    for j in range(nl + 1):
        cv.line([(0, j * lift), (nb * bay, j * lift)], "10-安全設施", 0.3)
    for i in range(nb):
        for j in range(nl):
            cv.line([(i * bay, j * lift), ((i + 1) * bay, (j + 1) * lift)], "10-安全設施", 0.15)
            cv.line([((i + 1) * bay, j * lift), (i * bay, (j + 1) * lift)], "10-安全設施", 0.15)
            cv.line([(i * bay, j * lift + 0.35), ((i + 1) * bay, j * lift + 0.35)], "10-安全設施", 0.12, ls="dashed")
    tv, th = R("scaf_tie_v"), R("scaf_tie_h")
    y = 0.0
    while y <= nl * lift:
        x = 0.0
        while x <= nb * bay:
            cv.circle((x, y), 0.18, "10-安全設施", fill="#d62728")
            x += th
        y += tv
    cv.dim((0, 0), (th, 0), -0.6, f"≤{th * 100:.0f}")
    cv.dim((nb * bay, 0), (nb * bay, tv), -0.6, f"≤{tv * 100:.0f}")
    cv.dim((0, nl * lift), (0, nl * lift + 1.0), 0.6, f"≥{R('scaf_top_margin') * 100:.0f}")
    cv.leader((th, tv), (th + 1.5, tv + 1.5), "● 壁連座（繫牆桿）")
    cv.leader((bay * 0.5, lift * 1.2), (-1.5, lift * 2.5), "交叉拉桿＋下拉桿（內外側）")
    cv.text((nb * bay / 2, nl * lift + 1.8), "框式施工架 立面圖（外覆防塵網）", 9, bold=True)
    ox = nb * bay + 6
    ground(cv, ox - 1, ox + 4)
    cv.rect(ox - 0.3, 0, 0.3, nl * lift + 1.2, layer="20-構造物", lw=0.5, fill="#cccccc", hatch="//")
    g = R("scaf_wall_gap"); dw = 0.6
    x1 = ox + g + 0.1; x2 = x1 + dw
    for x in (x1, x2):
        cv.line([(x, 0), (x, nl * lift + 1.0)], "10-安全設施", 0.4)
    for j in range(1, nl + 1):
        cv.rect(x1, j * lift - 0.05, dw, 0.05, layer="10-安全設施", lw=0.3, fill="#8c564b")
    cv.line([(x2, 2 * lift), (x2 + 2.2, 2 * lift + 1.4)], "10-安全設施", 0.4)
    cv.text((x2 + 1.5, 2 * lift + 1.9), "斜籬／安全網（外伸依第22條）", 6)
    cv.dim((ox, lift), (x1, lift), -0.4, f"≤{g * 100:.0f}")
    cv.dim((x1, lift * 2), (x2, lift * 2), 0.5, f"≥{R('scaf_deck_w') * 100:.0f}")
    cv.text((ox + 1.2, -0.8), "斷面圖", 9, bold=True)
    hd, ad = R("scaf_design")
    notes = [f"連接間距 垂直 ≤ {tv:g} m、水平 ≤ {th:g} m：{cite('scaf_tie_v')}",
             f"工作臺寬 ≥ {R('scaf_deck_w') * 100:.0f} cm，踏板縫 ≤ {R('scaf_deck_gap') * 100:.0f} cm，低於立柱頂 ≥ {R('scaf_top_margin'):g} m：{cite('scaf_deck_w')}",
             f"施工架與構造物間隙 ≤ {g * 100:.0f} cm（超過設補助板料或安全網）：{cite('scaf_wall_gap')}",
             f"高 ≥ {hd:g} m 且立面 ≥ {ad:g} m² 須設計簽章：{cite('scaf_design')}；高 ≥ {R('scaf_supervisor'):g} m 指派作業主管：{cite('scaf_supervisor')}",
             f"安全網攔截高度 ≤ {R('net_height'):g} m，符合 CNS 14252／16079：{cite('net_height')}；外伸寬度：{cite('net_extend')}",
             f"結構體施工架外緣覆蓋防塵網或防塵布：空污辦法 第11條【已核】",
             f"兩端立架、轉角及上下設備處設護欄；設安全上下設備。",
             f"架高、跨距、層高依設計（示意 {Hs:g} m × {Ls:g} m）。"]
    return cv, "D08 施工架及安全網詳圖", notes


def D09(pr, site):
    L, Ld = _p(pr, "l", 5.0)
    cv = Canvas()
    ground(cv, -0.5, L + 0.5)
    guardrail_elev(cv, 0, 0, L)
    cv.dim((0, 0), (0, R("guard_toe")), 0.35, f"≥{R('guard_toe') * 100:.0f}")
    cv.text((L / 2, -0.7), "鋼管護欄 立面圖", 9, bold=True)
    ox = L + 2.0
    ground(cv, ox - 0.8, ox + 1.2)
    cv.rect(ox - 0.019, 0, 0.038, R("guard_top") + 0.05, layer="10-安全設施", lw=0.4, fill="#666")
    for y in (R("guard_top"), R("guard_top") / 2):
        cv.circle((ox + 0.04, y), 0.019, "10-安全設施", fill="#666")
    cv.rect(ox + 0.06, 0, 0.02, R("guard_toe"), layer="10-安全設施", lw=0.3, fill="#ffd54f")
    cv.leader((ox + 0.04, R("guard_top")), (ox + 0.8, R("guard_top") + 0.25), f"上欄杆 φ≥{R('guard_pipe_d') * 1000:.0f}mm")
    cv.leader((ox + 0.04, R("guard_top") / 2), (ox + 0.8, R("guard_top") / 2 + 0.2), "中欄杆")
    cv.leader((ox + 0.07, R("guard_toe") / 2), (ox + 0.8, 0.2), "腳趾板")
    cv.text((ox + 0.3, -0.7), "斷面圖", 9, bold=True)
    notes = [f"上欄杆高 ≥ {R('guard_top') * 100:.0f} cm；上、中欄杆與樓板間開口 ≤ {R('guard_gap') * 100:.0f} cm：{cite('guard_top')}",
             f"腳趾板高 ≥ {R('guard_toe') * 100:.0f} cm：{cite('guard_toe')}",
             f"鋼管欄杆及杆柱直徑 ≥ {R('guard_pipe_d') * 1000:.0f} mm；杆柱間距 ≤ {R('guard_post_steel'):g} m：{cite('guard_post_steel')}",
             f"上欄杆任一點任何方向承受 {R('guard_load')} kgf 無顯著變形：{cite('guard_load')}",
             f"護欄前方 {R('guard_clear'):g} m 內不得堆放物料、停放機械或使用梯凳：{cite('guard_clear')}",
             f"適用處所：高度 2 m 以上之開口、樓梯、坡道、工作臺、擋土設施、構臺邊緣等：{cite('fall_height')}"]
    return cv, "D09 護欄標準詳圖", notes


def D10(pr, site):
    a, ad = _p(pr, "a", 1.2)
    cv = Canvas()
    cv.rect(-0.4, -0.4, a + 0.8, a + 0.8, layer="20-構造物", lw=0.3, fill="#eeeeee")
    cv.rect(0, 0, a, a, layer="20-構造物", lw=0.4, ls="dashed")
    cv.rect(-0.15, -0.15, a + 0.3, a + 0.3, layer="10-安全設施", lw=0.5, fill="#ffd54f", alpha=0.8)
    k = -0.15
    while k < a + 0.15:
        cv.line([(k, -0.15), (k + 0.15, a + 0.15)], "10-安全設施", 0.1, color="#333")
        k += 0.3
    cv.text((a / 2, a / 2), "開口 請勿移動\n（黃色警告標示）", 7, bold=True)
    cv.dim((0, -0.4), (a, -0.4), -0.35, _sx(a, ad) + "（開口）")
    cv.text((a / 2, a + 0.8), "開口護蓋 平面圖", 9, bold=True)
    ox = a + 2.2
    cv.rect(ox - 0.8, -0.25, 0.8, 0.25, layer="20-構造物", lw=0.4, fill="#cccccc", hatch="//")
    cv.rect(ox + a, -0.25, 0.8, 0.25, layer="20-構造物", lw=0.4, fill="#cccccc", hatch="//")
    cv.rect(ox - 0.15, 0, a + 0.3, 0.03, layer="10-安全設施", lw=0.4, fill="#ffd54f")
    for x in (ox - 0.02, ox + a - 0.02):
        cv.rect(x, -0.12, 0.04, 0.12, layer="10-安全設施", lw=0.3, fill="#555")
    cv.leader((ox + 0.0, -0.06), (ox - 0.6, -0.8), "止滑擋塊（防止滑動、移位）")
    cv.text((ox + a / 2, 0.7), "斷面圖", 9, bold=True)
    notes = [f"護蓋具承受人員、車輛通過之強度；供車輛通行者以後軸載重 2 倍設計：{cite('cover_grid')}",
             f"柵狀護蓋間隔 ≤ {R('cover_grid') * 100:.0f} cm；臨時開口護蓋漆黃色並標示警告：{cite('cover_grid')}",
             "護蓋固定防止滑動、掉落或移位；上方不得放置超過設計強度之重物。",
             f"高度 2 m 以上之開口應設護欄、護蓋或安全網：{cite('fall_height')}",
             "護蓋板厚與擋塊尺寸依開口尺寸及荷重設計（示意）。"]
    return cv, "D10 開口護蓋詳圖", notes


def D11(pr, site):
    nsub = int(float(pr.get("subpanels", 3)))
    cv = Canvas()
    cv.rect(0, 10, 3, 2, layer="08-臨時用電", lw=0.5, fill="#ffffcc"); cv.text((1.5, 11), "台電引接\n電表", 7)
    cv.line([(3, 11), (5, 11)], "08-臨時用電", 0.6)
    cv.rect(5, 9.5, 4, 3, layer="08-臨時用電", lw=0.6, fill="#ffff99"); cv.text((7, 11.4), "總配電盤", 8, bold=True)
    cv.text((7, 10.4), "主斷路器＋中感度\n高速型漏電斷路器", 5.6)
    cv.line([(9, 11), (11, 11)], "08-臨時用電", 0.6)
    cv.line([(11, 11 + (nsub - 1) * 1.6), (11, 11 - 3.2)], "08-臨時用電", 0.6)
    names = [f"分電箱-{x}" for x in str(pr.get("loads", "")).replace(",", "、").split("、") if x] or ["分電箱-加工場", "分電箱-結構樓層", "分電箱-工務所照明", "分電箱-抽水機", "分電箱-其他"]
    for i in range(nsub):
        y = 11 + (nsub - 1) * 1.6 - i * 3.2 / max(1, nsub - 1) * (nsub - 1) / max(1, nsub - 1) * 1.0 - i * 0.0
        y = 11 + (nsub - 1) * 1.6 - i * 3.2
        cv.line([(11, y), (13, y)], "08-臨時用電", 0.5)
        cv.rect(13, y - 0.8, 4, 1.6, layer="08-臨時用電", lw=0.5, fill="#ffffcc"); cv.text((15, y), names[i % len(names)], 6.5)
        cv.line([(17, y), (19, y)], "08-臨時用電", 0.4)
        cv.rect(19, y - 0.45, 2.2, 0.9, layer="08-臨時用電", lw=0.4); cv.text((20.1, y), "ELCB\n30mA 0.1s", 5.2)
        cv.line([(21.2, y), (23, y)], "08-臨時用電", 0.4)
        cv.text((23.2, y), ["插座分路→手提電動機具", "插座分路→移動式機具", "照明分路"][i % 3], 6, ha="left")
    y = 11 - 3.2 * nsub - 0.5
    cv.line([(11, 11 - 3.2), (11, y)], "08-臨時用電", 0.6)
    cv.line([(11, y), (13, y)], "08-臨時用電", 0.5)
    cv.rect(13, y - 0.8, 4, 1.6, layer="08-臨時用電", lw=0.5, fill="#ffffcc"); cv.text((15, y), "交流電焊機", 6.5)
    cv.text((17.3, y), "← 自動電擊防止裝置（CNS 4782）", 6, ha="left")
    y2 = y - 2.6
    cv.line([(11, y), (11, y2)], "08-臨時用電", 0.6); cv.line([(11, y2), (13, y2)], "08-臨時用電", 0.5)
    cv.rect(13, y2 - 0.8, 4, 1.6, layer="08-臨時用電", lw=0.5, fill="#ffffcc"); cv.text((15, y2), "起重機專用迴路", 6.5)
    for gx in (7,):
        cv.line([(gx, 9.5), (gx, 8.6)], "08-臨時用電", 0.3)
        for k, w in enumerate((0.6, 0.4, 0.2)):
            cv.line([(gx - w / 2, 8.6 - k * 0.15), (gx + w / 2, 8.6 - k * 0.15)], "08-臨時用電", 0.3)
    cv.text((7, 8.0), "接地", 6)
    cv.text((12, 13.6 + (nsub - 1) * 1.6), "臨時用電系統單線圖（不依比例）", 9, bold=True)
    notes = [f"移動式或攜帶式電動機具（對地 150 V 以上、潮濕場所、鋼架上等）連接電路設高敏感度高速型漏電斷路器 {R('elcb_high')[0]} mA、{R('elcb_high')[1]} s 以內：{cite('elcb_high')}",
             f"建築或工程興建之臨時用電，外殼接地電阻符合時得用中感度高速型（{R('elcb_mid')[0]}～{R('elcb_mid')[1]} mA）：{cite('elcb_mid')}",
             f"交流電焊機於良導體狹小空間或鋼架上作業設自動電擊防止裝置：{cite('welder_vsd')}",
             "漏電斷路器以設於分路為原則；配電箱加鎖、防雨、張貼負責人與檢點紀錄。",
             "電纜架高或穿管保護，不得置於車行路徑地面；分路數與容量由合格電機人員設計。",
             "起重機作業半徑內之架空電線須洽電業單位防護或遷移。"]
    return cv, "D11 臨時用電系統詳圖", notes


def D12(pr, site):
    w, wd = _p(pr, "w", 0.4)
    d, dd = _p(pr, "d", 0.4)
    cv = Canvas()
    cv.poly([(0, 0), (30, 0), (30, 20), (0, 20)], "00-基地界線", 0.4)
    cv.poly([(0.6, 0.6), (29.4, 0.6), (29.4, 19.4), (0.6, 19.4)], "09-給排水", 0.6)
    for p, q in (((5, 0.6), (8, 0.6)), ((29.4, 5), (29.4, 8)), ((15, 19.4), (18, 19.4))):
        _arrow(cv, p, q, layer="09-給排水")
    cv.rect(25, 0.9, 3.6, 2.4, layer="11-環保設施", lw=0.5, fill="#74c476")
    cv.text((26.8, 2.1), "沉砂池", 7)
    cv.leader((28.6, 1.0), (32, -1.5), "放流口→排水溝（經主管機關同意）")
    cv.rect(8, 6, 14, 8, layer="20-構造物", lw=0.4, hatch="//")
    cv.text((15, 10), "開挖／施工區（裸露地覆蓋防塵網、導水）", 7)
    cv.text((15, 21.5), "截水導水系統 平面示意圖", 9, bold=True)
    k = 8.0  # 斷面放大倍率（示意）
    ox, oy = 36, 12
    ground(cv, ox - 1.5, ox + w * k + 1.5, oy)
    cv.poly([(ox, oy), (ox, oy - d * k), (ox + w * k, oy - d * k), (ox + w * k, oy)], "09-給排水", 0.6)
    cv.rect(ox - 0.8, oy - d * k - 0.8, w * k + 1.6, 0.8, layer="20-構造物", lw=0.3, fill="#bbbbbb", hatch="..")
    cv.rect(ox, oy - d * k, w * k, d * k * 0.4, layer="09-給排水", lw=0.1, fill="#c6dbef", alpha=0.6)
    cv.dim((ox, oy - d * k - 0.8), (ox + w * k, oy - d * k - 0.8), -0.8, _sx(w, wd))
    cv.dim((ox + w * k + 0.8, oy - d * k), (ox + w * k + 0.8, oy), -0.8, _sx(d, dd))
    cv.text((ox + w * k / 2, oy - d * k - 3.2), f"（斷面放大 {k:g} 倍繪製）", 6.5)
    cv.text((ox + w * k / 2, oy + 1.5), "截水溝斷面", 9, bold=True)
    notes = [f"營建工地逕流廢水污染削減計畫施工前報核；圖面標示遮雨、擋雨、導雨設施及沉砂池：{cite('runoff_plan')}",
             "遮雨：帆布覆蓋或開挖面鋪設；擋雨：擋水牆、砂包；導雨：排水溝或臨時土溝（地方環保局宣導資料）。",
             f"裸露區域採行防制措施面積比例：第一級 ≥ {R('bare_lv1'):.0%}、第二級 ≥ {R('bare_lv2'):.0%}：{cite('bare_lv1')}",
             "截水溝斷面、坡度與沉砂池容量依集水面積與降雨強度設計（示意值）。",
             "沉砂池定期清淤；颱風豪雨前加強檢查。"]
    return cv, "D12 截水溝及沉砂池詳圖", notes


def D13(pr, site):
    cw, cwd = _p(pr, "unit_w", 3.0)
    cl, cld = _p(pr, "unit_l", 6.0)
    n = int(float(pr.get("units", 4)))
    rooms = [r for r in str(pr.get("rooms", "")).replace(",", "、").split("、") if r] or ["機關／監造辦公室", "承攬廠商辦公室", "會議室", "資料室／試驗室", "茶水間", "安衛室"][:n]
    n = len(rooms)
    cv = Canvas()
    for i, r in enumerate(rooms):
        x = i * cw
        cv.rect(x, 0, cw, cl, layer="04-臨時建物", lw=0.6, fill="#deebf7")
        cv.text((x + cw / 2, cl / 2), r, 7)
        cv.arc((x + 0.1, 0), 0.9, 0, 90, "04-臨時建物", 0.2)
        cv.line([(x + 0.1, 0), (x + 0.1, 0.9)], "04-臨時建物", 0.3)
        cv.line([(x + cw * 0.3, cl), (x + cw * 0.7, cl)], "04-臨時建物", 1.2, color="#3182bd")
    cv.rect(0, -1.5, n * cw, 1.5, layer="03-道路鋪面", lw=0.3, fill="#eeeeee")
    cv.text((n * cw / 2, -0.75), "走廊／雨遮", 7)
    cv.dim((0, cl), (n * cw, cl), 0.6, _sx(n * cw, cwd))
    cv.dim((0, 0), (0, cl), 0.6, _sx(cl, cld))
    cv.leader((n * cw, cl * 0.3), (n * cw + 1.2, cl * 0.1), "滅火器")
    cv.leader((n * cw, cl * 0.7), (n * cw + 1.2, cl * 0.9), "急救箱")
    cv.text((n * cw / 2, cl + 1.6), "工務所 平面圖（組合屋／貨櫃屋單元）", 9, bold=True)
    notes = ["工務所位置避開起重機作業半徑、開挖影響範圍與主要車行動線。",
             "房間組成、單元尺寸依契約（01500、01510 臨時房舍及監工站；示意值）。",
             "電源由分電箱引接並設漏電斷路器；設滅火器、急救箱與緊急聯絡資訊。",
             f"高氣溫戶外作業者，休息場所設置依設施規則（113.08.01 修正）辦理。",
             "基礎墊高、防颱繫固依設計；二層以上組合屋須檢核結構與樓梯。"]
    return cv, "D13 工務所詳圖", notes


def D14(pr, site):
    wk = (site or {}).get("project", {}).get("workers", {})
    m = int(float(pr.get("male", wk.get("male", 50))))
    fe = int(float(pr.get("female", wk.get("female", 5))))
    ms = max(1, math.ceil(m / R("toilet_m_seat")[0])) if m else 0
    mu = max(1, math.ceil(m / R("toilet_m_urinal")[0])) if m else 0
    fs = max(1, math.ceil(fe / R("toilet_f_seat")[0])) if fe else 0
    shw_m = int(float(pr.get("shower_m", max(1, math.ceil(m / 25)) if m else 0)))
    shw_f = int(float(pr.get("shower_f", 1 if fe else 0)))
    cv = Canvas()
    st = 1.0
    wm = max(ms, mu * 0.7, shw_m) * st + 2.0
    wf = max(fs, shw_f) * st + 2.0
    cv.rect(0, 0, wm, 6, layer="04-臨時建物", lw=0.6, fill="#deebf7")
    cv.rect(wm, 0, wf, 6, layer="04-臨時建物", lw=0.6, fill="#fde0ef")
    for i in range(ms):
        cv.rect(0.2 + i * st, 4.5, st - 0.05, 1.4, layer="04-臨時建物", lw=0.3); cv.circle((0.2 + i * st + st / 2, 5.3), 0.2, "04-臨時建物")
    for i in range(mu):
        cv.rect(0.3 + i * 0.7, 3.1, 0.4, 0.3, layer="04-臨時建物", lw=0.3)
    for i in range(shw_m):
        cv.rect(0.2 + i * st, 0.2, st - 0.05, 1.2, layer="04-臨時建物", lw=0.3, hatch="++")
    for i in range(fs):
        x = wm + 0.2 + i * st
        cv.rect(x, 4.5, st - 0.05, 1.4, layer="04-臨時建物", lw=0.3); cv.circle((x + st / 2, 5.3), 0.2, "04-臨時建物")
        cv.rect(x + st - 0.3, 4.6, 0.2, 0.2, layer="04-臨時建物", lw=0.2, fill="#999")
    for i in range(shw_f):
        cv.rect(wm + 0.2 + i * st, 0.2, st - 0.05, 1.2, layer="04-臨時建物", lw=0.3, hatch="++")
    for x0, w_ in ((0, wm), (wm, wf)):
        cv.rect(x0 + w_ - 1.6, 2.0, 1.4, 0.5, layer="09-給排水", lw=0.3)
        cv.text((x0 + w_ - 0.9, 2.25), "洗手台", 5.5)
    cv.text((wm / 2, 2.6), f"男廁／男浴室\n便坑 {ms}・便池 {mu}・淋浴 {shw_m}", 7, bold=True)
    cv.text((wm + wf / 2, 2.6), f"女廁／女浴室\n便坑 {fs}・淋浴 {shw_f}\n（設加蓋桶）", 7, bold=True)
    cv.line([(wm * 0.4, 0), (wm * 0.4 + 0.9, 0)], "04-臨時建物", 1.4, color="#ffffff")
    cv.line([(wm + wf * 0.4, 0), (wm + wf * 0.4 + 0.9, 0)], "04-臨時建物", 1.4, color="#ffffff")
    cv.text((wm * 0.4 + 0.45, -0.5), "男 入口", 6.5); cv.text((wm + wf * 0.4 + 0.45, -0.5), "女 入口", 6.5)
    cv.dim((0, 6), (wm + wf, 6), 0.6, "依設計")
    cv.text(((wm + wf) / 2, 7.6), f"男女廁所浴室 平面圖（同時作業 男 {m}／女 {fe} 人）", 9, bold=True)
    notes = [f"男用便坑每 {R('toilet_m_seat')[0]} 人 1 個（最少每 {R('toilet_m_seat')[1]} 人 1 個）：{cite('toilet_m_seat')}",
             f"男用便池每 {R('toilet_m_urinal')[0]} 人 1 個：{cite('toilet_m_urinal')}",
             f"女用便坑每 {R('toilet_f_seat')[0]} 人 1 個；女廁設加蓋桶：{cite('toilet_f_seat')}",
             "男女廁所分別設置、入口分開並明顯標示；設充分供應清潔水質之洗手設備。",
             f"淋浴間數量非法規值（示意：男每 25 人 1 間），依契約或工程需要調整。",
             "污水接化糞池或專用槽並定期抽除，不得排入雨水溝；流動廁所可計入便器數。"]
    return cv, "D14 男女廁所及浴室詳圖", notes


def D15(pr, site):
    W, Wd = _p(pr, "w", 20.0)
    D, Dd = _p(pr, "d", 12.0)
    vw, vwd = _p(pr, "vehicle_w", 2.5)
    cv = Canvas()
    cv.rect(0, 0, W, D, layer="05-堆置加工", lw=0.6)
    aisle = vw + 1
    zones = [("鋼筋（墊木架高、分號數標示）", "#fdae6b"), ("模板／支撐材", "#fdd0a2"), ("砂石（覆蓋防塵布）", "#d9b38c"), ("其他材料", "#fee6ce")]
    zw = W / 4
    for i, (nm, col) in enumerate(zones):
        cv.rect(i * zw + 0.2, aisle + 0.2, zw - 0.4, D - aisle - 0.4, layer="05-堆置加工", lw=0.4, fill=col, alpha=0.85)
        cv.text((i * zw + zw / 2, aisle + (D - aisle) / 2), nm, 6.5)
    cv.rect(0, 0, W, aisle, layer="03-道路鋪面", lw=0.3, fill="#e0e0e0")
    cv.text((W / 2, aisle / 2), f"搬運通道（單行 ≥ 車寬＋1 m＝{aisle:g} m，待核）", 7)
    cv.line([(0, D + 2.0), (W, D + 2.0)], "07-開挖擋土", 0.6, ls="dashed")
    cv.text((W / 2, D + 2.4), "開挖邊緣／護欄（示例位置）", 6.5, color="#a0005a")
    cv.poly([(0, D), (W, D), (W, D + 2.0), (0, D + 2.0)], "10-安全設施", 0.2, fill="#fb6a4a", alpha=0.3)
    cv.text((W / 2, D + 1.0), f"護欄前 {R('guard_clear'):g} m 淨空（不得堆置）", 6.5, color="#b30000")
    cv.dim((0, 0), (W, 0), -0.8, _sx(W, Wd))
    cv.dim((W, 0), (W, D), -0.8, _sx(D, Dd))
    cv.text((W / 2, D + 4.0), "材料堆置場 平面圖", 9, bold=True)
    notes = [f"粉塵逸散性材料（砂石、土方、廢棄物）覆蓋防塵布、防塵網或噴灑化學穩定劑：{cite('stock_cover')}",
             f"護欄前 {R('guard_clear'):g} m 內不得堆放物料：{cite('guard_clear')}",
             f"開挖面上方不得堆積土石，距開挖邊緣淨距 ≥ 開挖深 H：{cite('excav_stock')}",
             f"搬運通道寬度：{cite('road_one_way')}",
             f"建築材料、機具及廢棄物堆放於安全圍籬內：{cite('taipei_stock_inside')}",
             "堆置高度、墊木間距、分區面積依材料數量與吊運方式設計（示意值）；基坑周邊堆載經擋土設計者確認。"]
    return cv, "D15 材料堆置場詳圖", notes


DETAILS = {f"D{i:02d}": fn for i, fn in enumerate([D01, D02, D03, D04, D05, D06, D07, D08, D09, D10, D11, D12, D13, D14, D15], 1)}
NTS = {"D11"}


def run_detail(did, params, site, d, pages=None, sheets=None):
    cv, title, notes = DETAILS[did](params, site)
    base = os.path.join(d, did)
    paths = {"pages": pages} if pages is not None else {"png": base + ".png", "svg": base + ".svg", "pdf": base + ".pdf"}
    s = render(cv, paths, title, did, notes=notes, project=(site or {}).get("project"), nts=did in NTS)
    if pages is None:
        write_dxf(cv, base + ".dxf", text_scale=s / 1000 * 2.83)
    if sheets is not None:
        sheets.append(sheet_data(cv, title, did, s, notes, nts=did in NTS))
    return title, s


# ───────────────────────── AI 生圖提示詞 ─────────────────────────
def _dir(c, ref):
    dx, dy = c[0] - ref[0], c[1] - ref[1]
    if abs(dx) < 0.15 * max(abs(dx) + abs(dy), 1) * 2 and abs(dy) < 3:
        return "中央"
    ns = "北" if dy > 0 else "南"
    ew = "東" if dx > 0 else "西"
    if abs(dx) > 2.2 * abs(dy):
        return f"{ew}側"
    if abs(dy) > 2.2 * abs(dx):
        return f"{ns}側"
    return f"{ew}{ns}角"


def prompt_layout(site):
    P = site.get("project", {})
    c = centroid(site["site"]["boundary"])
    items = []
    for f in site.get("facilities", []):
        items.append(f"{f.get('label', FTYPE.get(f['type'], FTYPE['other'])[0])}位於基地{_dir(centroid(rect_pts(f)), c)}")
    for g in site.get("gates", []):
        items.append(f"大門位於基地{_dir(tuple(g['at']), c)}，臨接道路")
    for cr in site.get("cranes", []):
        items.append(f"{cr.get('label', '起重機')}位於{_dir(tuple(cr['at']), c)}")
    roads = "、".join(f"{r['name']}（{r['width']:g} m）" for r in site["site"].get("roads", []))
    labels = [f.get("label", FTYPE.get(f["type"], FTYPE["other"])[0]) for f in site.get("facilities", [])][:10]
    return f"""[整體佈局]
台灣營建工地 3D 鳥瞰示意圖，45 度俯視角，構圖涵蓋整個基地與臨接道路{('：' + roads) if roads else ''}。基地四周為連續施工圍籬，{'、'.join(items)}。{('構造物：' + site['building'].get('label', '')) if site.get('building') else ''}{('；開挖深 ' + str(site['excavation']['depth_m']) + ' m 之基坑，周邊設護欄') if site.get('excavation') else ''}。

[配色與插畫風格]
寫實 3D CGI 渲染，工程簡報用；晴天柔光；圍籬綠色系，臨時建物白色組合屋，安全設施黃黑警示色，車行路徑灰色鋪面，沉砂池藍色水面；乾淨、無雜亂。

[插畫內容描述]
清楚呈現洗車台緊鄰大門內側並連接沉砂池；材料堆置場以防塵布覆蓋；施工架外覆防塵網；起重機作業半徑以淡色地面圓弧示意；人員穿反光背心與安全帽；工務所與廁所遠離起重機作業範圍。

[要渲染進圖片的實際文字內容]
{('、'.join(labels))}（每個標籤字數少、字體大而清晰，正體中文）

[絕對禁止事項]
不得出現真實公司名稱、商標、人名、電話；不得出現簡體字；不得出現未列於上方的文字；不得出現無安全帽人員、人員站在吊物下方、堆置物緊貼開挖邊緣等違規畫面；不得把示意圖標示為施工圖。
"""


DETAIL_DESC = {
    "D01": "施工圍籬立面與斷面：定著地面全阻隔式鍍鋅鋼板圍籬、下方混凝土防溢座、立柱與斜撐、頂部紅色警示燈",
    "D02": "施工大門：雙扇向內開啟鋼製大門，下半部不透空，門柱兩側接圍籬，門口交通引導人員",
    "D03": "洗車台：混凝土洗車平台兩側噴水管，四周防溢座，末端廢水收集坑，連接三格沉砂池與回收泵浦",
    "D04": "工程告示牌：雙柱支撐之告示牌，表格欄位與透視圖區，設於工地大門旁",
    "D05": "施工構台：H 型鋼主梁與中間柱，鋪設覆工板，邊緣設上中欄杆與腳趾板，構台上有挖土機作業",
    "D06": "出土坡道：由地面斜向開挖底之鋪面坡道，兩側護欄，土方車上下",
    "D07": "開挖周邊：擋土壁與多層水平支撐的基坑剖面，頂部周邊護欄與截水溝，坑邊淨空不堆置",
    "D08": "施工架：框式施工架外覆防塵網，交叉拉桿與下拉桿，壁連座，工作臺滿鋪踏板，斜籬安全網",
    "D09": "護欄：上欄杆、中欄杆、腳趾板與杆柱之鋼管護欄近景",
    "D10": "開口護蓋：黃色護蓋覆蓋樓板開口，警告標語，周邊止滑擋塊",
    "D11": "臨時用電：防雨上鎖之配電箱，內有漏電斷路器，電纜架高，接地線",
    "D12": "截水溝與沉砂池：工地周邊排水溝導向沉砂池，裸露地覆蓋防塵網",
    "D13": "工務所：組合屋辦公室群，走廊雨遮，門口滅火器與急救箱",
    "D14": "男女廁所浴室：男女分開入口與標示之組合屋廁所浴室，洗手台",
    "D15": "材料堆置場：鋼筋架高於墊木並分號標示，模板堆置，砂石覆蓋防塵布，搬運通道",
}


def prompt_detail(did):
    return f"""[整體佈局]
台灣營建工地之構造示意圖，主題：{DETAIL_DESC[did]}；3/4 等角視角，主體置中、四周留白。

[配色與插畫風格]
寫實 3D CGI 技術插圖，乾淨淺灰背景，安全設施採黃黑警示色，鋼材金屬灰，混凝土淺灰。

[插畫內容描述]
清楚表達構件之組成與相對位置，比例合理；人員（若出現）穿反光背心、戴安全帽。

[要渲染進圖片的實際文字內容]
（不渲染任何文字；尺寸與條文標註以程式詳圖 {did} 為準）

[絕對禁止事項]
不得出現文字、數字、商標、簡體字；不得出現違反安全規定之畫面；不得作為施工圖使用。
"""



# ───────────────────────── 缺漏資料檢查（先詢問再執行） ─────────────────────────
def _get(d, path):
    for k in path.split("."):
        if not isinstance(d, dict) or k not in d:
            return None
        d = d[k]
    return d


LAYOUT_REQ = [
    ("project.name", "工程名稱（可用「○○」代替真實名稱）"),
    ("project.stage", "施工階段（S1 開工整備、S2 擋土基樁、S3 開挖支撐、S4 地下結構、S5 地上結構、S6 外牆裝修、S7 完工復原、S8 道路管線、S9 橋梁）"),
    ("project.type", "工程類別（建築／道路隧道／管線／橋梁）— 決定營建工程分級門檻"),
    ("project.area_m2", "施工面積（m²）— 計算營建工程分級"),
    ("project.duration_months", "工期（月）— 計算營建工程分級"),
    ("project.air_zone", "工地所在空氣品質防制區（第 1／2／3 級）— 決定第二級工程圍籬高度"),
    ("project.city", "工程所在縣市 — 判定是否適用地方規定"),
    ("project.public_work", "是否為公共工程（是／否）"),
    ("project.above_audit_amount", "是否達查核金額以上（是／否）— 告示牌應載事項"),
    ("project.workers.male", "同時作業男性人數 — 計算男用便器數"),
    ("project.workers.female", "同時作業女性人數（無則填 0）— 計算女用便器數"),
    ("project.paved_ratio", "車行路徑鋪設比例（%）"),
    ("site.boundary", "基地界線各角點座標或各邊長度（m）與形狀"),
    ("site.roads", "臨接道路：名稱、路寬（m）、位於基地哪一側"),
    ("fence.height_m", "擬設圍籬高度（m）與型式（全阻隔／半阻隔／簡易）"),
    ("vehicle.max_width_m", "最大進出車輛寬度（m）— 檢核車道寬度"),
    ("gates", "大門數量、位置（哪一側、距角點幾 m）與寬度（m）；是否供運輸車輛出入"),
    ("facilities", "各設施之位置與尺寸（長×寬 m）：工務所、廁所浴室、洗車台、沉砂池、材料堆置場、加工場、配電盤、告示牌、滅火器、急救站等"),
    ("excavation", "本階段有無開挖？有則提供開挖範圍、深度（m）與擋土型式"),
    ("cranes", "有無起重機？有則提供型式、位置與作業半徑（m）"),
    ("power_lines", "基地周邊有無架空電線？有則提供位置與電壓（kV）"),
    ("haul_roads", "場內道路路線、寬度（m）、單行或雙向、鋪面材料"),
]
FAC_NUM = {"toilet": [("seats_m", "男用便坑數"), ("urinals", "男用便池數"), ("seats_f", "女用便坑數")]}

DETAIL_REQ = {
    "D01": [("post", "圍籬立柱間距（m）"), ("h|site_level", "圍籬高度（m），或提供工程分級與防制區由程式判定")],
    "D02": [("w", "大門寬度（m）"), ("h", "大門高度（m）")],
    "D03": [("l", "洗車台長度（m）"), ("w|auto", "洗車台寬度（m）；屬區域開發或疏濬工程之自動洗車者改提供 auto=1 與 truck_w")],
    "D04": [("w", "告示牌寬度（m）"), ("h", "告示牌高度（m）"), ("leg", "告示牌底緣離地高度（m）")],
    "D05": [("span", "構台跨距（m）"), ("bays", "跨數"), ("h", "構台面高出原地面（m）")],
    "D06": [("depth", "坡道高差（開挖深度，m）"), ("slope_n", "坡度 1:n 之 n 值"), ("w", "坡道寬度（m）")],
    "D07": [("depth|site_excav", "開挖深度（m）")],
    "D08": [("h", "施工架高度（m）"), ("l", "施工架立面長度（m）"), ("lift", "施工架層高（m）"), ("bay", "施工架跨距（m）")],
    "D09": [],
    "D10": [("a", "開口邊長（m）")],
    "D11": [("subpanels", "分電箱數量"), ("loads", "各分電箱供電對象（以「、」分隔，例：加工場、結構樓層、照明）")],
    "D12": [("w", "截水溝寬度（m）"), ("d", "截水溝深度（m）")],
    "D13": [("rooms", "工務所房間組成（以「、」分隔）"), ("unit_w", "組合屋單元寬度（m）"), ("unit_l", "組合屋單元深度（m）")],
    "D14": [("male|site_workers", "同時作業男性人數"), ("female|site_workers", "同時作業女性人數"), ("shower_m", "男用淋浴間數"), ("shower_f", "女用淋浴間數")],
    "D15": [("w", "堆置場長度（m）"), ("d", "堆置場深度（m）"), ("vehicle_w", "搬運車輛寬度（m）")],
}
LAYOUT_ONLY = {"D09": "護欄繪製段長度為版面參數，不影響規定值"}


def missing_layout(site):
    q = []
    for path, text in LAYOUT_REQ:
        v = _get(site, path)
        if v is None or v == "" or (path in ("site.boundary", "gates", "facilities") and not v):
            q.append((path, text))
    for f in site.get("facilities", []) or []:
        lack = [k for k in ("x", "y", "w", "h") if k not in f]
        if lack:
            q.append((f"facilities.{f.get('id', f.get('type'))}", f"{f.get('label', FTYPE.get(f.get('type'), FTYPE['other'])[0])} 之位置與尺寸（{'、'.join(lack)}）"))
        for k, t in FAC_NUM.get(f.get("type"), []):
            if k not in f:
                q.append((f"facilities.{f.get('id')}.{k}", f"{f.get('label', '廁所')}：{t}"))
    for g in site.get("gates", []) or []:
        for k, t in (("at", "位置"), ("width", "寬度（m）"), ("dir", "面向（東西南北）")):
            if k not in g:
                q.append((f"gates.{g.get('id')}.{k}", f"大門 {g.get('id', '')} {t}"))
    ex = site.get("excavation")
    if ex:
        for k, t in (("polygon", "開挖範圍"), ("depth_m", "開挖深度（m）"), ("shoring", "擋土型式")):
            if k not in ex:
                q.append((f"excavation.{k}", t))
    for c in site.get("cranes", []) or []:
        for k, t in (("at", "位置"), ("radius", "作業半徑（m）")):
            if k not in c:
                q.append((f"cranes.{c.get('id')}.{k}", f"起重機 {c.get('id', '')} {t}"))
    for h in site.get("haul_roads", []) or []:
        for k, t in (("width", "寬度（m）"), ("one_way", "單行或雙向")):
            if k not in h:
                q.append((f"haul_roads.{h.get('id')}.{k}", f"場內道路 {h.get('id', '')} {t}"))
    stg = str(_get(site, "project.stage") or "")
    if any(x in stg for x in ("S5", "S6")) and not site.get("scaffold"):
        q.append(("scaffold", "施工架高度（m）與立面面積（m²）— 判定設計簽章與作業主管"))
    return q


def missing_detail(did, params, site):
    q = []
    site = site or {}
    for key, text in DETAIL_REQ[did]:
        alts = key.split("|")
        ok = False
        for a in alts:
            if a in params:
                ok = True
            elif a == "site_level" and eng_level(site.get("project", {}))[0] and (eng_level(site.get("project", {}))[0] == 1 or site.get("project", {}).get("air_zone")):
                ok = True
            elif a == "site_excav" and _get(site, "excavation.depth_m") is not None:
                ok = True
            elif a == "site_workers" and _get(site, "project.workers." + alts[0]) is not None:
                ok = True
        if not ok:
            q.append((f"{did}.{alts[0]}", text))
    if did == "D03" and str(params.get("auto", "0")) in ("1", "true", "True") and "truck_w" not in params:
        q.append(("D03.truck_w", "運輸車輛寬度（m）— 自動洗車台寬度須大於 1.2 倍車寬"))
    return q


def write_questions(q, d, title):
    os.makedirs(d, exist_ok=True)
    L = [f"# 執行前須確認事項｜{title}", "", "下列項目未提供，依本 skill 規定先詢問、不以預設值或示意值代替：", ""]
    L += [f"{i}. {t}（欄位 `{k}`）" for i, (k, t) in enumerate(q, 1)]
    L += ["", "全部提供後重新執行；若使用者明確同意以示意值繪製，加 --allow-demo（圖面將標「示意」）。"]
    open(os.path.join(d, "questions.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("\n".join(L))
    return 3


# ───────────────────────── Canvas 互動圖（單檔 HTML） ─────────────────────────
def sheet_data(cv, title, dwg_no, scale, notes, nts=False, legend=None, review_items=None):
    return {"title": title, "dwg": dwg_no, "scale": scale, "nts": nts, "notes": list(notes),
            "layers": {k: [v[0], v[2]] for k, v in LAYERS.items()}, "items": cv.items,
            "legend": legend or [], "review": review_items or []}


def write_canvas_html(sheets, path, project_name):
    data = json.dumps({"project": project_name, "sheets": sheets}, ensure_ascii=False)
    html = CANVAS_TEMPLATE.replace("__DATA__", data.replace("</", "<\\/"))
    open(path, "w", encoding="utf-8").write(html)
    return path


CANVAS_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-Hant-TW"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>工地設施配置圖 Canvas</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:"Noto Sans TC","Microsoft JhengHei","PingFang TC",sans-serif;background:#f3f4f2;color:#222;display:flex;flex-direction:column;height:100vh}
header{display:flex;align-items:center;gap:10px;padding:8px 12px;background:#1f4e3d;color:#fff;flex-wrap:wrap}
header h1{font-size:15px;margin:0 8px 0 0;font-weight:600}
select,button{font:inherit;font-size:13px;padding:4px 8px;border-radius:4px;border:1px solid #9bb;background:#fff;color:#222;cursor:pointer}
main{flex:1;display:flex;min-height:0}#wrap{flex:1;position:relative;min-width:0}canvas{width:100%;height:100%;display:block;background:#fff;cursor:grab}
aside{width:300px;overflow:auto;border-left:1px solid #ccd;background:#fafbfa;padding:10px;font-size:12.5px}
aside h2{font-size:13px;margin:12px 0 6px;color:#1f4e3d;border-bottom:1px solid #cde;padding-bottom:3px}
.ly label{display:flex;align-items:center;gap:6px;margin:2px 0}.sw{width:14px;height:10px;border:1px solid #666;display:inline-block}
ol{padding-left:18px;margin:4px 0}li{margin:3px 0}table{border-collapse:collapse;width:100%;font-size:11.5px}td,th{border:1px solid #ccd;padding:3px;vertical-align:top}
.s-不符{color:#b00020;font-weight:700}.s-缺項{color:#c05000;font-weight:700}.s-注意{color:#a07000}.s-符合{color:#2a7a3a}
#info{position:absolute;left:8px;bottom:8px;background:rgba(255,255,255,.88);padding:3px 8px;font-size:12px;border:1px solid #ccd;border-radius:4px}
@media(max-width:800px){main{flex-direction:column}aside{width:100%;height:38vh;border-left:0;border-top:1px solid #ccd}}
</style></head><body>
<header><h1 id="pj"></h1><select id="sheet"></select><button id="fit">全圖</button><button id="png">匯出 PNG</button><span id="sc" style="font-size:12px;opacity:.85"></span></header>
<main><div id="wrap"><canvas id="cv"></canvas><div id="info">滾輪縮放・拖曳平移・雙擊全圖</div></div>
<aside><h2>圖層</h2><div class="ly" id="ly"></div><h2>附註</h2><ol id="nt"></ol><div id="rvw"></div></aside></main>
<script>
const D=__DATA__;
const cv=document.getElementById('cv'),ctx=cv.getContext('2d');let S=0,view={s:1,x:0,y:0},hidden=new Set(),dpr=window.devicePixelRatio||1;
document.getElementById('pj').textContent=D.project||'';
const sel=document.getElementById('sheet');D.sheets.forEach((s,i)=>{const o=document.createElement('option');o.value=i;o.textContent=s.dwg+' '+s.title;sel.appendChild(o)});
sel.onchange=()=>{S=+sel.value;hidden.clear();panel();fit()};
function ext(sh){let a=[1e9,1e9,-1e9,-1e9];const add=(x,y)=>{a[0]=Math.min(a[0],x);a[1]=Math.min(a[1],y);a[2]=Math.max(a[2],x);a[3]=Math.max(a[3],y)};
 for(const it of sh.items){if(it.pts)it.pts.forEach(p=>add(p[0],p[1]));else if(it.c){add(it.c[0]-it.r,it.c[1]-it.r);add(it.c[0]+it.r,it.c[1]+it.r)}else if(it.p)add(it.p[0],it.p[1])}return a}
function resize(){const r=cv.getBoundingClientRect();cv.width=r.width*dpr;cv.height=r.height*dpr;draw()}
function fit(){const sh=D.sheets[S],e=ext(sh),W=cv.width,H=cv.height,m=0.92;view.s=Math.min(W/(e[2]-e[0]||1),H/(e[3]-e[1]||1))*m;view.x=W/2-(e[0]+e[2])/2*view.s;view.y=H/2+(e[1]+e[3])/2*view.s;draw()}
const X=x=>x*view.s+view.x,Y=y=>-y*view.s+view.y;
function pt(sh){return sh.scale*0.0003528}
function dash(ls){return ls==='dashed'?[8*dpr,5*dpr]:ls==='dashdot'?[10*dpr,4*dpr,2*dpr,4*dpr]:[]}
function hatch(pts,h){ctx.save();ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(X(p[0]),Y(p[1])):ctx.moveTo(X(p[0]),Y(p[1])));ctx.closePath();ctx.clip();
 const xs=pts.map(p=>X(p[0])),ys=pts.map(p=>Y(p[1])),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),g=7*dpr;ctx.lineWidth=0.6*dpr;ctx.setLineDash([]);
 if(h.includes('.')||h.includes('+')){for(let x=x0;x<x1;x+=g)for(let y=y0;y<y1;y+=g){ctx.beginPath();ctx.arc(x,y,0.7*dpr,0,7);ctx.fill()}}
 else{for(let k=x0-(y1-y0);k<x1;k+=g){ctx.beginPath();ctx.moveTo(k,y1);ctx.lineTo(k+(y1-y0),y0);ctx.stroke()}}ctx.restore()}
function draw(){const sh=D.sheets[S];ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#fff';ctx.fillRect(0,0,cv.width,cv.height);const P=pt(sh);
 for(const it of sh.items){if(hidden.has(it.layer))continue;const L=sh.layers[it.layer]||['#000','solid'];const col=it.color||L[0];ctx.strokeStyle=col;ctx.fillStyle=col;
  ctx.lineWidth=Math.min(Math.max(0.6*dpr,(it.lw||0.3)*2.2*P*view.s*0.5),8*dpr);ctx.setLineDash(dash(it.ls||L[1]));
  if(it.k==='line'||it.k==='poly'){ctx.beginPath();it.pts.forEach((p,i)=>i?ctx.lineTo(X(p[0]),Y(p[1])):ctx.moveTo(X(p[0]),Y(p[1])));if(it.k==='poly'){ctx.closePath();
    if(it.fill){ctx.save();ctx.globalAlpha=it.alpha??1;ctx.fillStyle=it.fill;ctx.fill();ctx.restore()}if(it.hatch){ctx.save();ctx.strokeStyle=col;ctx.fillStyle=col;hatch(it.pts,it.hatch);ctx.restore();ctx.beginPath();it.pts.forEach((p,i)=>i?ctx.lineTo(X(p[0]),Y(p[1])):ctx.moveTo(X(p[0]),Y(p[1])));ctx.closePath()}ctx.setLineDash(dash(it.ls||L[1]))}ctx.stroke()}
  else if(it.k==='circle'){ctx.beginPath();ctx.arc(X(it.c[0]),Y(it.c[1]),Math.max(it.r*view.s,1),0,7);if(it.fill){ctx.save();ctx.globalAlpha=it.alpha??1;ctx.fillStyle=it.fill;ctx.fill();ctx.restore()}ctx.stroke()}
  else if(it.k==='arc'){ctx.beginPath();ctx.arc(X(it.c[0]),Y(it.c[1]),it.r*view.s,-it.a1*Math.PI/180,-it.a0*Math.PI/180);ctx.stroke()}
  else if(it.k==='dot'){ctx.beginPath();ctx.arc(X(it.p[0]),Y(it.p[1]),1.6*dpr,0,7);ctx.fill()}
  else if(it.k==='tick'){const l=1.6e-3*sh.scale,a=it.ang+Math.PI/4;ctx.setLineDash([]);ctx.lineWidth=0.8*dpr;ctx.beginPath();ctx.moveTo(X(it.p[0]-l*Math.cos(a)),Y(it.p[1]-l*Math.sin(a)));ctx.lineTo(X(it.p[0]+l*Math.cos(a)),Y(it.p[1]+l*Math.sin(a)));ctx.stroke()}
  else if(it.k==='text'||it.k==='dimtext'){let fs=it.size*P*view.s;if(fs<3*dpr)continue;let x=it.p[0],y=it.p[1];if(it.k==='dimtext'){const o=4*P;x+=it.n[0]*o;y+=it.n[1]*o}
    ctx.save();ctx.translate(X(x),Y(y));ctx.rotate(-(it.rot||0)*Math.PI/180);ctx.fillStyle=it.k==='dimtext'?'#333':(it.color||'#000');ctx.font=(it.bold?'700 ':'')+fs+'px "Noto Sans TC","Microsoft JhengHei",sans-serif';
    ctx.textAlign=it.ha||'center';const lines=String(it.s).split('\n'),lh=fs*1.18,off=it.va==='center'||!it.va?-(lines.length-1)*lh/2:0;ctx.textBaseline='middle';lines.forEach((t,i)=>ctx.fillText(t,0,off+i*lh));ctx.restore()}}
 document.getElementById('sc').textContent=sh.nts?'不依比例（NTS）':'圖紙比例 1:'+sh.scale+'（A3）';}
function panel(){const sh=D.sheets[S],ly=document.getElementById('ly');ly.innerHTML='';const used=[...new Set(sh.items.map(i=>i.layer))].sort();
 used.forEach(n=>{const l=document.createElement('label');l.innerHTML=`<input type="checkbox" checked><span class="sw" style="background:${(sh.layers[n]||['#000'])[0]}"></span>${n}`;l.querySelector('input').onchange=e=>{e.target.checked?hidden.delete(n):hidden.add(n);draw()};ly.appendChild(l)});
 document.getElementById('nt').innerHTML=sh.notes.map(n=>`<li>${n.replace(/</g,'&lt;')}</li>`).join('');
 const r=document.getElementById('rvw');r.innerHTML=sh.review.length?'<h2>審查結果</h2><table><tr><th>規則</th><th>判定</th><th>項目／發現</th></tr>'+sh.review.map(x=>`<tr><td>${x.rule}</td><td class="s-${x.status}">${x.status}</td><td><b>${x.item}</b><br>${x.finding}<br><small>${x.basis}</small></td></tr>`).join('')+'</table>':''}
let drag=null;cv.onmousedown=e=>{drag=[e.clientX,e.clientY];cv.style.cursor='grabbing'};window.onmouseup=()=>{drag=null;cv.style.cursor='grab'};
window.onmousemove=e=>{if(!drag)return;view.x+=(e.clientX-drag[0])*dpr;view.y+=(e.clientY-drag[1])*dpr;drag=[e.clientX,e.clientY];draw()};
cv.onwheel=e=>{e.preventDefault();const r=cv.getBoundingClientRect(),mx=(e.clientX-r.left)*dpr,my=(e.clientY-r.top)*dpr,f=e.deltaY<0?1.15:1/1.15;view.x=mx-(mx-view.x)*f;view.y=my-(my-view.y)*f;view.s*=f;draw()};
cv.ondblclick=fit;document.getElementById('fit').onclick=fit;
let tp=null;cv.addEventListener('touchstart',e=>{tp=[...e.touches].map(t=>[t.clientX,t.clientY])},{passive:true});
cv.addEventListener('touchmove',e=>{e.preventDefault();const t=[...e.touches].map(t=>[t.clientX,t.clientY]);if(t.length===1&&tp&&tp.length===1){view.x+=(t[0][0]-tp[0][0])*dpr;view.y+=(t[0][1]-tp[0][1])*dpr}
 else if(t.length===2&&tp&&tp.length===2){const d0=Math.hypot(tp[0][0]-tp[1][0],tp[0][1]-tp[1][1]),d1=Math.hypot(t[0][0]-t[1][0],t[0][1]-t[1][1]),f=d1/d0,r=cv.getBoundingClientRect(),mx=((t[0][0]+t[1][0])/2-r.left)*dpr,my=((t[0][1]+t[1][1])/2-r.top)*dpr;view.x=mx-(mx-view.x)*f;view.y=my-(my-view.y)*f;view.s*=f}tp=t;draw()},{passive:false});
document.getElementById('png').onclick=()=>{const a=document.createElement('a');a.download=D.sheets[S].dwg+'.png';a.href=cv.toDataURL('image/png');a.click()};
window.onresize=resize;panel();resize();fit();
</script></body></html>"""



# ───────────────────────── 3D 鳥瞰圖（程式繪製，單檔 HTML Canvas） ─────────────────────────
# 顯示高度（m）：僅供 3D 呈現，非設計值；設施可以 height_m 覆寫
SHOW_H = {"office": 2.8, "toilet": 2.6, "shower": 2.6, "rest": 2.6, "guard": 2.6, "lab": 2.8, "store": 1.2,
          "rebar": 0.9, "formwork": 1.5, "precast": 1.2, "waste": 1.0, "soil": 2.0, "washer": 0.25, "sedtank": 0.05,
          "panel": 1.8, "subpanel": 1.4, "water": 2.0, "sign": 3.2, "fire": 1.0, "firstaid": 2.4, "cctv": 4.5,
          "deck": 0.4, "ramp": 0.3, "hoist": None, "parking": 0.05, "other": 1.5}
COL3 = {"office": "#dfe9f5", "toilet": "#d6e4f0", "shower": "#d6e4f0", "rest": "#e8f0f8", "guard": "#cfe0f2",
        "lab": "#dfe9f5", "store": "#e9c79b", "rebar": "#b5651d", "formwork": "#d9a066", "precast": "#c8c8c8",
        "waste": "#8fae7a", "soil": "#9c7a54", "washer": "#9bc9a0", "sedtank": "#4a90c8", "panel": "#f2d541",
        "subpanel": "#f2d541", "water": "#7fb2e5", "sign": "#f6e7a1", "fire": "#e03b2f", "firstaid": "#f4a6a0",
        "cctv": "#666666", "deck": "#a99bc9", "ramp": "#b0a080", "hoist": "#a49cc8", "parking": "#bbbbbb", "other": "#dddddd"}


def build_scene(site):
    F, L, T = [], [], []   # faces, lines, labels

    def face(pts, col, a=1.0):
        F.append({"p": [[round(x, 3), round(y, 3), round(z, 3)] for x, y, z in pts], "c": col, "a": a})

    def box(poly, z0, z1, col, a=1.0, top=None):
        n = len(poly)
        face([(x, y, z1) for x, y in poly], top or col, a)
        for i in range(n):
            (x1, y1), (x2, y2) = poly[i], poly[(i + 1) % n]
            face([(x1, y1, z0), (x2, y2, z0), (x2, y2, z1), (x1, y1, z1)], col, a)

    def line(pts, col, w=1.0, dash=False):
        L.append({"p": [[round(x, 3), round(y, 3), round(z, 3)] for x, y, z in pts], "c": col, "w": w, "d": dash})

    def label(p, s, col="#111"):
        T.append({"p": [round(v, 3) for v in p], "s": s, "c": col})

    S = site["site"]; B = S["boundary"]
    xs = [p[0] for p in B]; ys = [p[1] for p in B]
    pad = 18
    face([(min(xs) - pad, min(ys) - pad, -0.06), (max(xs) + pad, min(ys) - pad, -0.06), (max(xs) + pad, max(ys) + pad, -0.06), (min(xs) - pad, max(ys) + pad, -0.06)], "#d8dccf")
    for rd in S.get("roads", []):
        face([(x, y, -0.03) for x, y in offset_polyline(rd["line"], rd["width"])], "#6f7377")
        m = rd["line"][len(rd["line"]) // 2] if len(rd["line"]) > 2 else centroid(rd["line"])
        label((m[0], m[1], 0.5), f"{rd['name']}（{rd['width']:g} m）", "#333")
    face([(x, y, 0.0) for x, y in B], "#cdb98f")
    for hr in site.get("haul_roads", []):
        face([(x, y, 0.02) for x, y in offset_polyline(hr["line"], hr["width"])], "#a7a9a6")
    # 開挖與構造物
    ex = site.get("excavation")
    if ex:
        face([(x, y, 0.03) for x, y in ex["polygon"]], "#5b4a3a")
        gp = _inset(ex["polygon"], -0.5)
        for i in range(len(gp)):
            a, b = gp[i - 1], gp[i]
            line([(a[0], a[1], 1.0), (b[0], b[1], 1.0)], "#d62728", 1.6)
            line([(a[0], a[1], 0.5), (b[0], b[1], 0.5)], "#d62728", 1.0)
    bld = site.get("building")
    if bld:
        H = float(bld.get("height_m", 0) or 0) or 3.0
        fp = bld["footprint"]
        box(fp, 0.03, H, "#c9c9c4", 1.0, "#b8b8b2")
        k = 3.5
        z = k
        while z < H:
            for i in range(len(fp)):
                a, b = fp[i - 1], fp[i]
                line([(a[0], a[1], z), (b[0], b[1], z)], "#8f8f8a", 0.6)
            z += k
        if site.get("scaffold"):
            sp = _inset(fp, -1.2)
            sh = min(float(site["scaffold"].get("height_m", H)), H + 1.5)
            box(sp, 0.03, sh, "#3f8f4f", 0.28)
        c = centroid(fp)
        label((c[0], c[1], H + 2), bld.get("label", "新建構造物"))
    # 圍籬（避開大門）
    fh = float(site.get("fence", {}).get("height_m", 0) or 0)
    if fh:
        fp = _inset(B, 0.3)
        gates = site.get("gates", [])
        for i in range(len(fp)):
            a, b = fp[i], fp[(i + 1) % len(fp)]
            segs = [(0.0, 1.0)]
            Lg = math.hypot(b[0] - a[0], b[1] - a[1]) or 1
            for g in gates:
                t = ((g["at"][0] - a[0]) * (b[0] - a[0]) + (g["at"][1] - a[1]) * (b[1] - a[1])) / Lg ** 2
                d = seg_dist(g["at"], a, b)
                if d < 1.0 and 0 <= t <= 1:
                    h = g["width"] / 2 / Lg
                    new = []
                    for s0, s1 in segs:
                        if t - h > s0: new.append((s0, min(s1, t - h)))
                        if t + h < s1: new.append((max(s0, t + h), s1))
                    segs = new
            for s0, s1 in segs:
                p0 = (a[0] + (b[0] - a[0]) * s0, a[1] + (b[1] - a[1]) * s0)
                p1 = (a[0] + (b[0] - a[0]) * s1, a[1] + (b[1] - a[1]) * s1)
                face([(p0[0], p0[1], 0), (p1[0], p1[1], 0), (p1[0], p1[1], fh), (p0[0], p0[1], fh)], "#4f9a5a", 0.9)
                face([(p0[0], p0[1], 0), (p1[0], p1[1], 0), (p1[0], p1[1], 0.3), (p0[0], p0[1], 0.3)], "#a0a0a0", 1.0)
    for g in site.get("gates", []):
        x, y = g["at"]; w = g["width"]; d = g.get("dir", "S")
        hz = d in ("S", "N")
        for s in (-1, 1):
            px, py = (x + s * w / 2, y) if hz else (x, y + s * w / 2)
            box([(px - .2, py - .2), (px + .2, py - .2), (px + .2, py + .2), (px - .2, py + .2)], 0, (fh or 2.4) + .3, "#e07b1a")
        label((x, y, (fh or 2.4) + 1.6), f"{g.get('id', '')} 大門", "#b35a00")
    # 設施
    bh = float((bld or {}).get("height_m", 0) or 0)
    for f in site.get("facilities", []):
        t = f["type"]; pts = rect_pts(f)
        h = f.get("height_m") or SHOW_H.get(t) or 1.5
        if t == "hoist":
            h = bh + 3 if bh else 10
        col = COL3.get(t, "#ddd")
        if t == "sedtank":
            face([(x, y, 0.04) for x, y in pts], col)
        elif t in ("sign", "cctv"):
            c = centroid(pts)
            box([(c[0] - .08, c[1] - .08), (c[0] + .08, c[1] - .08), (c[0] + .08, c[1] + .08), (c[0] - .08, c[1] + .08)], 0, h - (1.4 if t == "sign" else 0), "#555")
            if t == "sign":
                box(pts, h - 1.6, h, col)
        else:
            box(pts, 0.02, h, col, 1.0)
            if t in ("office", "toilet", "rest", "guard", "lab", "shower", "firstaid"):
                box(pts, h, h + 0.12, "#7d8b99")
        lab = f.get("label", FTYPE.get(t, FTYPE["other"])[0])
        if t not in ("fire", "subpanel", "cctv"):
            c = centroid(pts)
            label((c[0], c[1], h + 1.2), lab)
    # 起重機
    for cr in site.get("cranes", []):
        x, y = cr["at"]; R_ = cr["radius"]
        Hc = float(cr.get("height_m") or (bh + 12 if bh else 30))
        box([(x - 1, y - 1), (x + 1, y - 1), (x + 1, y + 1), (x - 1, y + 1)], 0, Hc, "#f2c230")
        line([(x, y, Hc + .5), (x + R_, y, Hc + .5)], "#e0a800", 3)
        line([(x, y, Hc + .5), (x - R_ * .3, y, Hc + .5)], "#e0a800", 3)
        box([(x - R_ * .3 - 1.5, y - 1), (x - R_ * .3, y - 1), (x - R_ * .3, y + 1), (x - R_ * .3 - 1.5, y + 1)], Hc - 1.5, Hc + .5, "#777")
        line([(x, y, Hc + .5), (x, y, Hc + 6)], "#e0a800", 2)
        line([(x, y, Hc + 6), (x + R_ * .7, y, Hc + .5)], "#bbb", 0.8)
        line([(x, y, Hc + 6), (x - R_ * .3, y, Hc + .5)], "#bbb", 0.8)
        circ = [(x + R_ * math.cos(2 * math.pi * i / 72), y + R_ * math.sin(2 * math.pi * i / 72), 0.06) for i in range(73)]
        line(circ, "#7b4fb3", 1.2, True)
        label((x, y, Hc + 8), f"{cr.get('label', cr.get('id', '起重機'))}　R={R_:g} m", "#4b2a80")
    for pw in site.get("power_lines", []):
        pl = pw["line"]; zh = 9.0
        for x, y in pl:
            box([(x - .15, y - .15), (x + .15, y - .15), (x + .15, y + .15), (x - .15, y + .15)], 0, zh, "#555")
        line([(x, y, zh) for x, y in pl], "#d62728", 1.2)
        label((pl[0][0], pl[0][1], zh + 1.5), f"架空電線 {pw.get('voltage_kv', '?')} kV", "#b00020")
    return {"faces": F, "lines": L, "labels": T,
            "center": [(min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, 0], "span": max(max(xs) - min(xs), max(ys) - min(ys)),
            "hmax": max([p[2] for f in F for p in f["p"]] + [p[2] for l in L for p in l["p"]] + [1]),
            "north": S.get("north_deg", 0)}


def write_birdview_html(site, path):
    sc = build_scene(site)
    P = site.get("project", {})
    data = json.dumps({"scene": sc, "title": f"{P.get('name', '')}　{P.get('stage', '')}　3D 鳥瞰圖"}, ensure_ascii=False)
    open(path, "w", encoding="utf-8").write(BIRD_TEMPLATE.replace("__DATA__", data.replace("</", "<\\/")))
    return sc


BIRD_TEMPLATE = r"""<!DOCTYPE html><html lang="zh-Hant-TW"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>工地 3D 鳥瞰圖</title><style>
*{box-sizing:border-box}body{margin:0;font-family:"Noto Sans TC","Microsoft JhengHei","PingFang TC",sans-serif;height:100vh;display:flex;flex-direction:column;background:#eef1ec}
header{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:7px 12px;background:#1f4e3d;color:#fff}header h1{font-size:14px;margin:0 8px 0 0;font-weight:600}
button{font:inherit;font-size:12.5px;padding:3px 9px;border-radius:4px;border:1px solid #9bb;background:#fff;cursor:pointer}
#w{flex:1;position:relative}canvas{width:100%;height:100%;display:block;cursor:grab}
#tip{position:absolute;left:8px;bottom:8px;background:rgba(255,255,255,.9);border:1px solid #ccd;border-radius:4px;padding:3px 8px;font-size:12px}
#cap{position:absolute;right:8px;bottom:8px;background:rgba(255,255,255,.9);border:1px solid #ccd;border-radius:4px;padding:3px 8px;font-size:11.5px;color:#444;max-width:60%}
</style></head><body>
<header><h1 id="t"></h1><button data-v="home">預設視角</button><button data-v="ne">東北視角</button><button data-v="se">東南視角</button><button data-v="sw">西南視角</button><button data-v="top">俯視</button><button id="lb">標籤 開／關</button><button id="png">匯出 PNG</button></header>
<div id="w"><canvas id="c"></canvas><div id="tip">拖曳旋轉・Shift＋拖曳平移・滾輪縮放・淡色標籤＝被遮蔽之設施</div><div id="cap">程式依 site.json 座標繪製；設施高度為顯示用示意值，尺寸與規定以施工總平面配置圖為準</div></div>
<script>
const D=__DATA__,S=D.scene;document.getElementById('t').textContent=D.title;
const cv=document.getElementById('c'),g=cv.getContext('2d');let dpr=window.devicePixelRatio||1,showLb=true;
const FIT=Math.max(S.span*1.7,S.hmax*2.4),TZ=Math.min(S.hmax*0.3,S.span*0.25);let cam={yaw:-1.95,pitch:0.82,dist:FIT,tx:S.center[0],ty:S.center[1],tz:TZ};
const LIGHT=norm([-0.45,-0.6,0.85]);
function inPoly(p,P){let c=false;for(let i=0,j=P.length-1;i<P.length;j=i++){if((P[i][1]>p[1])!==(P[j][1]>p[1])&&p[0]<(P[j][0]-P[i][0])*(p[1]-P[i][1])/(P[j][1]-P[i][1]+1e-9)+P[i][0])c=!c}return c}
function norm(v){const l=Math.hypot(...v)||1;return v.map(x=>x/l)}
function hexrgb(h){h=h.replace('#','');if(h.length===3)h=h.split('').map(c=>c+c).join('');return[parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)]}
function basis(){const cy=Math.cos(cam.yaw),sy=Math.sin(cam.yaw),cp=Math.cos(cam.pitch),sp=Math.sin(cam.pitch);
 const eye=[cam.tx+cam.dist*cp*cy,cam.ty+cam.dist*cp*sy,cam.tz+cam.dist*sp];const f=norm([cam.tx-eye[0],cam.ty-eye[1],cam.tz-eye[2]]);
 let r=norm([f[1],-f[0],0]);const u=[r[1]*f[2]-r[2]*f[1],r[2]*f[0]-r[0]*f[2],r[0]*f[1]-r[1]*f[0]];return{eye,f,r,u}}
function proj(p,B,W,H){const d=[p[0]-B.eye[0],p[1]-B.eye[1],p[2]-B.eye[2]];const z=d[0]*B.f[0]+d[1]*B.f[1]+d[2]*B.f[2];if(z<0.5)return null;
 const fl=Math.min(W,H)*1.15;return[W/2+(d[0]*B.r[0]+d[1]*B.r[1]+d[2]*B.r[2])*fl/z,H/2-(d[0]*B.u[0]+d[1]*B.u[1]+d[2]*B.u[2])*fl/z,z]}
function draw(){const W=cv.width,H=cv.height,B=basis();const sky=g.createLinearGradient(0,0,0,H);sky.addColorStop(0,'#cfe3f2');sky.addColorStop(1,'#f4f6f0');g.fillStyle=sky;g.fillRect(0,0,W,H);
 const items=[];
 for(const f of S.faces){const pp=f.p.map(p=>proj(p,B,W,H));if(pp.some(q=>!q))continue;
  const a=f.p[0],b=f.p[1],c=f.p[2];let n=norm([(b[1]-a[1])*(c[2]-a[2])-(b[2]-a[2])*(c[1]-a[1]),(b[2]-a[2])*(c[0]-a[0])-(b[0]-a[0])*(c[2]-a[2]),(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])]);
  const cen=[0,1,2].map(k=>f.p.reduce((s,p)=>s+p[k],0)/f.p.length);const tv=[B.eye[0]-cen[0],B.eye[1]-cen[1],B.eye[2]-cen[2]];if(n[0]*tv[0]+n[1]*tv[1]+n[2]*tv[2]<0)n=n.map(x=>-x);
  const sh=0.55+0.45*Math.max(0,n[0]*LIGHT[0]+n[1]*LIGHT[1]+n[2]*LIGHT[2]);const flat=Math.abs(n[2])>0.99&&cen[2]<0.1;
  items.push({k:'f',z:pp.reduce((s,q)=>s+q[2],0)/pp.length+(flat?1e5-cen[2]*10:0),pp,c:hexrgb(f.c),sh,a:f.a})}
 for(const l of S.lines){for(let i=1;i<l.p.length;i++){const p0=proj(l.p[i-1],B,W,H),p1=proj(l.p[i],B,W,H);if(!p0||!p1)continue;const ground=l.p[i][2]<0.1;items.push({k:'l',z:(p0[2]+p1[2])/2+(ground?1e5-1:0)-0.01,p0,p1,c:l.c,w:l.w,d:l.d})}}
 items.sort((a,b)=>b.z-a.z);const solid=items.filter(it=>it.k==='f'&&it.a>0.6&&it.z<1e5);
 for(const it of items){if(it.k==='f'){g.beginPath();it.pp.forEach((q,i)=>i?g.lineTo(q[0],q[1]):g.moveTo(q[0],q[1]));g.closePath();
   const c=it.c.map(v=>Math.round(v*it.sh));g.fillStyle=`rgba(${c[0]},${c[1]},${c[2]},${it.a})`;g.fill();g.strokeStyle=`rgba(${Math.round(c[0]*.7)},${Math.round(c[1]*.7)},${Math.round(c[2]*.7)},${Math.min(1,it.a+.2)})`;g.lineWidth=0.6*dpr;g.stroke()}
  else{g.beginPath();g.moveTo(it.p0[0],it.p0[1]);g.lineTo(it.p1[0],it.p1[1]);g.strokeStyle=it.c;g.lineWidth=it.w*dpr*1.3;g.setLineDash(it.d?[7*dpr,5*dpr]:[]);g.stroke();g.setLineDash([])}}
 if(showLb){const lbs=S.labels.map(t=>({t,q:proj(t.p,B,W,H)})).filter(o=>o.q).map(o=>(o.hid=solid.some(f=>f.z<o.q[2]-0.5&&inPoly(o.q,f.pp)),o)).sort((a,b)=>b.q[2]-a.q[2]);const placed=[];
  g.font=`600 ${12*dpr}px "Noto Sans TC","Microsoft JhengHei",sans-serif`;g.textAlign='center';g.textBaseline='middle';
  for(const o of lbs){const w=g.measureText(o.t.s).width+10*dpr,h=18*dpr;let x=o.q[0],y=o.q[1]-14*dpr;
   for(let k=0;k<6&&placed.some(r=>Math.abs(r[0]-x)<(r[2]+w)/2&&Math.abs(r[1]-y)<h);k++)y-=h;placed.push([x,y,w]);
   g.strokeStyle='rgba(60,60,60,.55)';g.lineWidth=1*dpr;g.beginPath();g.moveTo(o.q[0],o.q[1]);g.lineTo(x,y+h/2);g.stroke();
   g.globalAlpha=o.hid?0.35:1;g.fillStyle='rgba(255,255,255,.88)';g.fillRect(x-w/2,y-h/2,w,h);g.strokeRect(x-w/2,y-h/2,w,h);g.fillStyle=o.t.c;g.fillText(o.t.s,x,y);g.globalAlpha=1}}
 // 指北
 const n0=proj([S.center[0],S.center[1],0],B,W,H),n1=proj([S.center[0]+Math.sin(S.north*Math.PI/180)*10,S.center[1]+Math.cos(S.north*Math.PI/180)*10,0],B,W,H);
 if(n0&&n1){const a=Math.atan2(n1[1]-n0[1],n1[0]-n0[0]),cx=W-48*dpr,cy=48*dpr,r=22*dpr;g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.arc(cx,cy,r+6*dpr,0,7);g.fill();g.strokeStyle='#333';g.stroke();
  g.fillStyle='#222';g.beginPath();g.moveTo(cx+Math.cos(a)*r,cy+Math.sin(a)*r);g.lineTo(cx+Math.cos(a+2.6)*r*.5,cy+Math.sin(a+2.6)*r*.5);g.lineTo(cx+Math.cos(a-2.6)*r*.5,cy+Math.sin(a-2.6)*r*.5);g.fill();
  g.font=`700 ${12*dpr}px sans-serif`;g.fillText('N',cx+Math.cos(a)*(r+13*dpr),cy+Math.sin(a)*(r+13*dpr))}}
function resize(){const r=cv.getBoundingClientRect();cv.width=r.width*dpr;cv.height=r.height*dpr;draw()}
let drag=null;cv.onmousedown=e=>{drag={x:e.clientX,y:e.clientY,s:e.shiftKey}};window.onmouseup=()=>drag=null;
window.onmousemove=e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.x=e.clientX;drag.y=e.clientY;
 if(drag.s||e.shiftKey){const B=basis(),k=cam.dist/700;cam.tx-=(B.r[0]*dx-0)*k;cam.ty-=(B.r[1]*dx)*k;const fx=B.f[0],fy=B.f[1],l=Math.hypot(fx,fy)||1;cam.tx+=fx/l*dy*k;cam.ty+=fy/l*dy*k}
 else{cam.yaw-=dx*0.006;cam.pitch=Math.min(1.55,Math.max(0.12,cam.pitch+dy*0.005))}draw()};
cv.onwheel=e=>{e.preventDefault();cam.dist*=e.deltaY<0?0.9:1.1;draw()};
let tp=null;cv.addEventListener('touchstart',e=>{tp=[...e.touches].map(t=>[t.clientX,t.clientY])},{passive:true});
cv.addEventListener('touchmove',e=>{e.preventDefault();const t=[...e.touches].map(t=>[t.clientX,t.clientY]);if(t.length===1&&tp&&tp.length===1){cam.yaw-=(t[0][0]-tp[0][0])*0.006;cam.pitch=Math.min(1.55,Math.max(0.12,cam.pitch+(t[0][1]-tp[0][1])*0.005))}
 else if(t.length===2&&tp&&tp.length===2){const d0=Math.hypot(tp[0][0]-tp[1][0],tp[0][1]-tp[1][1]),d1=Math.hypot(t[0][0]-t[1][0],t[0][1]-t[1][1]);cam.dist*=d0/d1}tp=t;draw()},{passive:false});
const V={home:[-1.95,0.82],ne:[0.785,0.82],se:[-0.785,0.82],sw:[-2.356,0.82],top:[-1.5708,1.5]};
document.querySelectorAll('[data-v]').forEach(b=>b.onclick=()=>{[cam.yaw,cam.pitch]=V[b.dataset.v];cam.tx=S.center[0];cam.ty=S.center[1];cam.tz=TZ;cam.dist=FIT;draw()});
document.getElementById('lb').onclick=()=>{showLb=!showLb;draw()};
document.getElementById('png').onclick=()=>{const a=document.createElement('a');a.download='birdview_3d.png';a.href=cv.toDataURL('image/png');a.click()};
window.onresize=resize;resize();
</script></body></html>"""


def cmd_birdview(a):
    site = load_site(a.site)
    os.makedirs(a.out, exist_ok=True)
    q = missing_layout(site)
    if q and not a.allow_demo:
        sys.exit(write_questions(q, a.out, site.get("project", {}).get("name", "3D 鳥瞰圖")))
    p = os.path.join(a.out, "birdview_3d.html")
    sc = write_birdview_html(site, p)
    png = None
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch(); pg = b.new_page(viewport={"width": 1600, "height": 1000}, device_scale_factor=1.5)
            pg.goto("file://" + os.path.abspath(p)); pg.wait_for_timeout(600)
            png = os.path.join(a.out, "birdview_3d.png")
            pg.locator("#c").screenshot(path=png); b.close()
    except Exception as e:
        print(f"（未產生 PNG：{str(e)[:80]}；請以 HTML 內「匯出 PNG」按鈕輸出）", file=sys.stderr)
    print(f"3D 鳥瞰圖 → {p}" + (f"、{png}" if png else "") + f"（面 {len(sc['faces'])}、標籤 {len(sc['labels'])}）")



# ───────────────────────── 指令 ─────────────────────────
def load_site(p):
    return json.load(open(p, encoding="utf-8")) if p else None


def cmd_layout(a, only_review=False):
    site = load_site(a.site)
    os.makedirs(a.out, exist_ok=True)
    q = missing_layout(site)
    if q and not a.allow_demo:
        sys.exit(write_questions(q, a.out, site.get("project", {}).get("name", "配置圖")))
    items = review(site)
    cnt = write_review(site, items, a.out)
    print("審查：", cnt)
    if only_review:
        return
    cv = build_layout(site)
    P = site.get("project", {})
    notes = [f"施工階段：{P.get('stage', '未提供')}",
             "本圖為施工總平面佈置圖，設施尺寸與位置依 site.json；正式施工以核定之施工計畫為準。",
             "審查意見詳 review.md；【待核】規則見 verify_list.csv。",
             f"圍籬：{cite('fence_h_lv1').split('【')[0]}；洗車：{cite('wash_basic').split('【')[0]}",
             "起重機作業半徑內禁止設置人員停留設施（起重規則第39條）。",
             "座標單位：公尺；基地尺寸依測量成果。"]
    if q:
        notes.insert(0, "【示意】部分資料未提供，經使用者同意以示意值繪製：" + "、".join(k for k, _ in q))
    base = os.path.join(a.out, "site_layout")
    s = render(cv, {"png": base + ".png", "svg": base + ".svg", "pdf": base + ".pdf"},
               f"施工總平面配置圖（{P.get('stage', '')}）", "L-01", scale=a.scale, notes=notes, project=P, legend=LEGEND,
               north=site["site"].get("north_deg", 0))
    write_dxf(cv, base + ".dxf", text_scale=s / 1000 * 2.83)
    order = {"不符": 0, "缺項": 1, "注意": 2, "缺資料": 3, "提醒": 4, "資訊": 5, "符合": 6}
    rv = sorted(items, key=lambda x: (order.get(x["status"], 9), x["rule"]))
    sheets = [sheet_data(cv, f"施工總平面配置圖（{P.get('stage', '')}）", "L-01", s, notes, review_items=rv)]
    write_canvas_html(sheets, os.path.join(a.out, "site_canvas.html"), P.get("name", ""))
    open(os.path.join(a.out, "prompt_layout.txt"), "w", encoding="utf-8").write(prompt_layout(site))
    rules_list(a.out)
    print(f"配置圖 1:{s} → {base}.png/.svg/.pdf/.dxf；Canvas → {a.out}/site_canvas.html")


def cmd_detail(a):
    site = load_site(a.site)
    os.makedirs(a.out, exist_ok=True)
    did = a.id.upper()
    params = dict(kv.split("=", 1) for kv in (a.param or []))
    q = missing_detail(did, params, site)
    if q and not a.allow_demo:
        sys.exit(write_questions(q, a.out, did))
    sheets = []
    t, s = run_detail(did, params, site, a.out, sheets=sheets)
    write_canvas_html(sheets, os.path.join(a.out, f"{did}_canvas.html"), (site or {}).get("project", {}).get("name", ""))
    open(os.path.join(a.out, f"prompt_{did}.txt"), "w", encoding="utf-8").write(prompt_detail(did))
    print(f"{t} 1:{s} → {a.out}（含 {did}_canvas.html）")


def cmd_details(a):
    """全部詳圖。--ids 指定編號；參數以 --param D03.l=8 形式提供。"""
    site = load_site(a.site)
    os.makedirs(a.out, exist_ok=True)
    ids = [x.upper() for x in (a.ids or DETAILS.keys())]
    allp = {}
    for kv in a.param or []:
        k, v = kv.split("=", 1)
        did, key = k.split(".", 1)
        allp.setdefault(did.upper(), {})[key] = v
    q = []
    for did in ids:
        q += missing_detail(did, allp.get(did, {}), site)
    if q and not a.allow_demo:
        sys.exit(write_questions(q, a.out, "構造詳圖"))
    _mpl()
    from matplotlib.backends.backend_pdf import PdfPages
    sheets = []
    with PdfPages(os.path.join(a.out, "details_all.pdf")) as pp:
        for did in ids:
            run_detail(did, allp.get(did, {}), site, a.out, sheets=sheets)
            t, s = run_detail(did, allp.get(did, {}), site, a.out, pages=pp)
            print(f"{did} {t} 1:{s}")
    write_canvas_html(sheets, os.path.join(a.out, "details_canvas.html"), (site or {}).get("project", {}).get("name", ""))


def cmd_check(a):
    site = load_site(a.site) if a.site else {}
    q = missing_layout(site) if a.site and not a.detail else []
    for did in (a.detail or []):
        q += missing_detail(did.upper(), dict(kv.split("=", 1) for kv in (a.param or [])), site)
    if q:
        sys.exit(write_questions(q, a.out, "檢查"))
    print("資料齊全，可執行。")


def cmd_prompt(a):
    os.makedirs(a.out, exist_ok=True)
    if a.target.upper() in DETAILS:
        txt = prompt_detail(a.target.upper()); fn = f"prompt_{a.target.upper()}.txt"
    else:
        txt = prompt_layout(load_site(a.target)); fn = "prompt_layout.txt"
    open(os.path.join(a.out, fn), "w", encoding="utf-8").write(txt)
    print(txt)


def rules_list(d):
    os.makedirs(d, exist_ok=True)
    cols = ["編號", "類別", "項目", "目前數值", "單位", "依據", "條號", "狀態", "備註"]
    allr, ver = [], []
    for k, r in RULES.items():
        v = r["value"]
        v = "、".join(str(x) for x in v) if isinstance(v, list) else ("" if v is None else str(v))
        row = [k, r["group"], r["item"], v, r["unit"], r["source"], r["clause"], VTAG.get(r["verified"], r["verified"]), r["note"]]
        allr.append(row)
        if r["verified"] != "web":
            ver.append(row)
    for fn, rows in (("rules_all.csv", allr), ("verify_list.csv", ver)):
        with open(os.path.join(d, fn), "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f); w.writerow(cols); w.writerows(rows)
    return len(allr), len(ver)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    for nm in ("layout", "review"):
        p = sp.add_parser(nm); p.add_argument("site"); p.add_argument("-o", "--out", default="out"); p.add_argument("--scale", type=int); p.add_argument("--allow-demo", action="store_true")
    p = sp.add_parser("detail"); p.add_argument("id"); p.add_argument("-o", "--out", default="out"); p.add_argument("--param", nargs="*"); p.add_argument("--site"); p.add_argument("--allow-demo", action="store_true")
    p = sp.add_parser("details"); p.add_argument("-o", "--out", default="out"); p.add_argument("--site"); p.add_argument("--ids", nargs="*"); p.add_argument("--param", nargs="*"); p.add_argument("--allow-demo", action="store_true")
    p = sp.add_parser("check"); p.add_argument("--site"); p.add_argument("--detail", nargs="*"); p.add_argument("--param", nargs="*"); p.add_argument("-o", "--out", default="out")
    p = sp.add_parser("birdview"); p.add_argument("site"); p.add_argument("-o", "--out", default="out"); p.add_argument("--allow-demo", action="store_true")
    p = sp.add_parser("prompt"); p.add_argument("target"); p.add_argument("-o", "--out", default="out")
    p = sp.add_parser("rules-list"); p.add_argument("-o", "--out", default="out")
    a = ap.parse_args()
    if a.cmd == "layout":
        cmd_layout(a)
    elif a.cmd == "review":
        cmd_layout(a, only_review=True)
    elif a.cmd == "detail":
        cmd_detail(a)
    elif a.cmd == "details":
        cmd_details(a)
    elif a.cmd == "prompt":
        cmd_prompt(a)
    elif a.cmd == "birdview":
        cmd_birdview(a)
    elif a.cmd == "check":
        cmd_check(a)
    else:
        n, v = rules_list(a.out)
        print(f"規則 {n} 項，非「已核」{v} 項 → {a.out}/verify_list.csv")


if __name__ == "__main__":
    main()
